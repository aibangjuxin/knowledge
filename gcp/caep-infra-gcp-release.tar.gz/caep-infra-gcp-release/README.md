# caep-infra-gcp-release

> **仓库性质:** GCP infra 工程师的 release 工程仓库。
> **对应人员:** Lex
> **运行环境:** 跳板机 (jumpbox) 上的 shell + jq 环境,实际操作 5 Region / N Project。

本仓库是 **每次 GCP infra release 的"实体档案"**。每个 release 是一个独立的目录,
记录该版本涉及的所有项目 (Project) 操作、变更工单 (Change Request, CR)、验证结果、
以及最终交付报告。release 目录只增不删,作为审计与回滚的证据。

> 🐚 **环境要求:** 仓库内所有脚本锁定到 `/opt/homebrew/bin/bash` (GNU bash 5.0+),
> 用到了 `${var^^}` 大小写转换、`mapfile`、`declare -a` 等 bash 5 特性。
> macOS 用户: `brew install bash`(系统自带 `/bin/bash` 是 3.2,缺关键特性)。
> Linux 用户: 装 `bash` 5.0+ 包。
> 兼容性警告机制: `common/lib/lib-bash-version.sh` 会在低版本运行时打 warning(不强制 exit)。

---

## 1. 目录速查

| 一级目录 | 用途 | 可写? |
|----------|------|-------|
| `common/lib/` | 跨 Region 共享的 shell 库 (GCS / GAR / Secret / DNS / IAM / GKE / Jump) | ⚠ PR review 必填 |
| `common/env.sh.template` | Region 无关的环境变量模板 | ⚠ PR review 必填 |
| `regions/<r>/env.sh` | Region 特定的 Project ID 列表 / 默认值 | ✅ 单人自由改 |
| `regions/<r>/projects/<pid>/` | 单个 Project 的资源台账与脚本 | ✅ 单人自由改 |
| `releases/_template/` | 新版本必须复制的模板(**只读**) | 🚫 任何人不准改 |
| `releases/caep-infra-vX.Y.Z/` | 单个 release 的完整档案 | ✅ 该版本 owner 自由改 |
| `docs/` | 跨 release 的方法论文档 | ⚠ PR review 必填 |
| `scripts/` | 跨 release 的辅助脚本 (new-release.sh 等) | ⚠ PR review 必填 |

🚫 = 任何人不准改(包括 AI)
⚠ = 需要 review 后合并
✅ = 单人自由改

---

## 2. Release 命名与生命周期

### 2.1 命名规范

```
caep-infra-v<MAJOR>.<MINOR>.<PATCH>
```

| 段 | 触发条件 | 示例 |
|----|----------|------|
| MAJOR | 不兼容的 infra 变更(例:跨 Region 网络拓扑重构、IAM 模型切换) | v1.0.0 → v2.0.0 |
| MINOR | 兼容的新功能(例:新增一个 Region、新增一类资源) | v1.0.0 → v1.1.0 |
| PATCH | 兼容的修复 / 配置微调 / 单 Project 内的小改 | v1.0.0 → v1.0.1 |

> 同步打 tag:`git tag -a caep-infra-vX.Y.Z -m "..."` 打在 release commit 上。

### 2.2 生命周期

```
planning → preflight → execute → verify → report → CR-close
   │          │          │         │         │         │
   ↓          ↓          ↓         ↓         ↓         ↓
releases/  scripts/  scripts/  scripts/  report/  cr/<id>/
pfb-gcp-v0.1.0/  preflight.sh  setup-*.sh  verify-*.sh  report.html  -filled.md
```

每个 release 目录在生命周期内**只增不删**。如果 release 中途回滚,**新建一个 `vX.Y.Z-rollback` 目录**,记录回滚动作,绝不覆盖原目录。

---

## 3. AI 协作协议(强约束)

本仓库是 AI 协作友好的:每次 release 都有大量重复性工作(写脚本、回填 CR、整理报告),
AI 可以做这些事。但**有些事 AI 绝对不能做**。

### 3.1 AI 可以做 ✅

- **填充 `releases/caep-infra-vX.Y.Z/README.md`** — 严格按 `_template/README.md` 的 section 顺序填,
  不删 section,空 section 写 `_(无)_`。
- **写 `releases/caep-infra-vX.Y.Z/scripts/` 下的脚本** — 复用 `common/lib/` 的 lib 函数,禁止重复实现。
- **生成 `report/report.html` 与 `report/summary.md`** — 基于 `artifacts/` 里的真实输出,绝不杜撰数字。
- **填充 `cr/<id>-filled.md`** — CR 回填模板,可由 AI 起草,但**回填前必须人工 review + 签字**。
- **改 `regions/<r>/env.sh`** — 增删 Project ID、调默认 Region,自由改。

### 3.2 AI 必须问 ⚠️

- 改 `common/lib/*` 之前 — 任何 lib 函数签名变更都影响所有 release,先 PR review。
- 改 `releases/_template/` 之前 — 模板是历史 release 的事实标准,改动会让历史 release "看起来不一致"。
- 改 `docs/release-process.md` 之前 — SOP 变更需要回填到所有未关闭 CR。

### 3.3 AI 绝对不能做 🚫

- **不删 release 目录** — 即使用户说"这个 release 是错的"或"回滚了",也不删。
  请新建一个 `vX.Y.Z-rollback` 目录记录回滚动作。
- **不写 `secrets/`、`*.env`、`*.key`、`*.tfstate`** — 本仓库的 `.gitignore` 已经隔离,
  但**任何对凭据的写入请求都要直接拒绝并提示用户用 Secret Manager**。
- **不杜撰 release 数据** — 不存在的 Project ID、虚构的 quota number、臆造的验证结果,
  一律填 `_(待人工填写)_`,并在 README 的 `## 6. 已知缺口` 列出。
- **不在 `cr/<id>.md` 里写"已批准"** — CR 状态必须来自 CR 系统,AI 只起草"待批准"的回填内容。

### 3.4 README 维护契约(重要)

每个 release 的 `README.md` 是 **AI 与人协作的核心**。结构在 `_template/README.md` 里
**已经固定**,AI 每次只填充、不改结构。完整 section 列表见 `_template/README.md` 第 1 节。

每次 release 结束时,**release owner 必须 review 整个 README**,
特别确认:

1. **第 6 节 "已知缺口"** 是否如实记录了所有"应该做但还没做"的事项。
2. **第 7 节 "踩坑实录"** 是否保留了可复现的报错原文 + 原因 + 修法(这三个缺一不可)。
3. **第 8 节 "CR 回填引用"** 是否只引用真实存在的 `cr/<id>-filled.md` 文件,不引用空想中的 ID。

---

## 4. 快速开始(5 分钟跑通一个版本)

```bash
# 1) 初始化一个新 release(基于 _template/)
./scripts/new-release.sh pfb-gcp-v0.1.0

# 2) 编辑 releases/pfb-gcp-v0.1.0/README.md 的"基本元信息"section
$EDITOR releases/pfb-gcp-v0.1.0/README.md

# 3) 写 preflight + setup + verify 脚本(复用 common/lib/)
cp common/lib/lib-bucket.sh releases/pfb-gcp-v0.1.0/scripts/
# ... 按需添加

# 4) 跑 preflight(在跳板机内)
ssh jumpbox-uk
cd /opt/caep-infra-gcp-release  # 跳板机上的同步路径
./releases/pfb-gcp-v0.1.0/scripts/preflight.sh

# 5) 跑 setup + verify
./releases/pfb-gcp-v0.1.0/scripts/setup-uk.sh
./releases/pfb-gcp-v0.1.0/scripts/verify-uk.sh

# 6) 把 artifacts/ 与 report/ 同步回本地
./scripts/cr-sync.sh --release v0.1.0 --pull

# 7) 提交
git add releases/pfb-gcp-v0.1.0/
git commit -m "release(pfb-gcp-v0.1.0): initial rollout across 5 regions"
git tag -a pfb-gcp-v0.1.0 -m "Release v0.1.0"
```

---

## 5. 跳板机工作流(本节由 Lex 维护)

- **所有 `gcloud` / `kubectl` / `terraform` 命令**统一在跳板机内执行,不在本地 mac 跑。
- 跳板机同步方式:**手动 rsync**(在 GitHub 接入前);后续 `./scripts/cr-sync.sh` 自动化。
- 跳板机上的 `common/lib/` 必须与本仓库**逐字一致** — `scripts/check-release.sh` 会做 diff 检查。

详见 `docs/architecture-overview.md` 第 3 节。

---

## 6. Git 协作约定

- **主分支:** `main` — 长期稳定,只接受已完成的 release(merge 自 `release/<v>` 分支)。
- **工作分支:** `release/pfb-gcp-vX.Y.Z` — 单个 release 的准备工作,由 `scripts/new-release.sh` 自动创建。
  PR 合并到 `main` 后打 **annotated tag** (`git tag -a <version> -m "..."`)。
- **回滚分支:** `hotfix/pfb-gcp-vX.Y.Z+1` — PATCH 级别修复,基于 tag 拉出。
- **提交规范:** **Conventional Commits 1.0.0** — `<type>(<scope>): <description>`,被 `.git/hooks/commit-msg` 强制。
  - `type` 必填: `feat` / `fix` / `chore` / `docs` / `refactor` / `perf` / `test` / `build` / `ci` / `release` / `revert`
  - `scope` 建议填: `lib-<name>` / `region-<r>` / `release` / `template` / `cr-<id>` / `docs`
  - `!` 表示 BREAKING CHANGE
  - **release commit 推荐格式:** `release: <one-line summary>`,版本号放在 body footer 的 `Release-As: <version>`
    (避免多个 `release(v0.1.0) ...` `release(v0.2.0) ...` 在 `git log` 里视觉撞车)
- **Tag 类型:** **必须 annotated** — `git tag -a`,**不**用 lightweight tag。
  `scripts/check-release.sh` §5 校验所有 release tag 都是 annotated。

---

## 7. 相关仓库

| 仓库 | 关系 |
|------|------|
| `~/git/gcp/` | **知识库**(脑外笔记),与本仓库**完全独立**。本仓库**不引用**知识库内容。 |
| `~/git/knowledge/` | 更上层的方法论存储。 |
| 远端 GitHub | 暂未接入,等公司网络允许后 `git remote add origin git@github.com:lex/caep-infra-gcp-release.git`。 |

> 📌 **本仓库不维护根级 `CHANGELOG.md`**。每个 release 的变更日志在 `releases/<v>/report/summary.md`
> (TL;DR + 做了什么 + 验证 + 已知风险),**`releases/` 目录序列就是本仓库的 changelog**。
> 如果将来接入 GitHub + 团队协作,可以考虑在每个 release 目录内嵌入自动生成的 `CHANGELOG.md`,
> 但不要在根目录建 CHANGELOG — 那是和"一个版本一个目录"哲学相反的设计。

---

## 8. License

Internal use only. 未授权外部分发。
