# common/

跨 Region、跨 Project 共享的 shell 库。所有 release 脚本都通过 `source` 加载这里的 lib。

---

## 调用约定(强约束)

### 1. 加载方式

```bash
# 在 release 脚本开头(三行)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../../.." && pwd)"
source "${ROOT_DIR}/common/lib/lib-log.sh"
source "${ROOT_DIR}/common/lib/lib-bucket.sh"
# ... 按需 source
```

### 2. 函数命名空间

| 前缀 | 含义 | 例 |
|------|------|-----|
| `_log_*` | 日志相关 | `_log_info`, `_log_error`, `_log_json` |
| `_bucket_*` | GCS 操作 | `_bucket_exists`, `_bucket_create` |
| `_gar_*` | Artifact Registry | `_gar_repo_create` |
| `_secret_*` | Secret Manager | `_secret_get`, `_secret_put` |
| `_dns_*` | Cloud DNS | `_dns_record_set` |
| `_iam_*` | IAM / SA | `_iam_sa_create`, `_iam_sa_bind_role` |
| `_gke_*` | GKE | `_gke_get_credentials` |
| `_jump_*` | 跳板机隧道 | `_jump_tunnel_open` |

下划线前缀 = "内部库函数",**禁止 release 脚本自己实现同名函数**。

### 3. 强制签名

每个 lib 函数都遵循:

```bash
_fn_name() {
    local arg1="$1" arg2="$2"
    # 1) 入参校验(失败时 _log_error + return 1)
    # 2) 调 gcloud / gsutil / kubectl
    # 3) jq 解析
    # 4) _log_json 输出
}
```

返回码: `0` = 成功,`1` = 入参错,`2` = gcloud 失败,`3` = jq 解析失败。

### 4. Region 上下文

所有函数**不隐式**绑定 Region/Project。调用方必须显式传 `PROJECT_ID` 和可选 `REGION`。
Region-specific 的默认值放在 `regions/<r>/env.sh`。

### 5. 凭据

**lib 函数永远不接触凭据文件**。`gcloud auth` 由用户登录态保证,SA 切换用
`_iam_sa_impersonate`。**禁止 lib 写 `/tmp/xxx-key.json`**。

---

## 当前 lib 列表

| 文件 | 状态 | 提供函数 |
|------|------|---------|
| `lib-log.sh` | ✅ 稳定 | `_log_info`, `_log_warn`, `_log_error`, `_log_json`, `_log_section` |
| `lib-bucket.sh` | 🟡 骨架 | `_bucket_exists`, `_bucket_create`, `_bucket_ls`, `_bucket_rm` |
| `lib-gar.sh` | 🟡 骨架 | `_gar_repo_exists`, `_gar_repo_create`, `_gar_image_ls` |
| `lib-secret.sh` | 🟡 骨架 | `_secret_exists`, `_secret_get`, `_secret_put`, `_secret_rm` |
| `lib-dns.sh` | 🟡 骨架 | `_dns_zone_exists`, `_dns_record_set`, `_dns_record_rm` |
| `lib-iam.sh` | 🟡 骨架 | `_iam_sa_create`, `_iam_sa_bind_role`, `_iam_sa_impersonate` |
| `lib-gke.sh` | 🟡 骨架 | `_gke_cluster_exists`, `_gke_get_credentials` |
| `lib-jump.sh` | 🟡 骨架 | `_jump_tunnel_open`, `_jump_tunnel_close` |

🟡 骨架 = 函数签名已定,body 是 TODO,需要在首次实际使用某个函数时**完整实现并 PR review**。
✅ 稳定 = 已实现 + 至少一个 release 用过。

---

## Git hooks(强约束)

本仓库的 git hooks 放在 `common/git-hooks/` 下,版本化、入仓、可重装。`.git/hooks/` 是 git 本地目录,不入仓。

### 当前 hooks

| hook | 作用 | 阻断? |
|------|------|------|
| `commit-msg` | 强制 [Conventional Commits 1.0.0](https://www.conventionalcommits.org/en/v1.0.0/) 格式: `<type>(<scope>)!: <description>` | ✅ 拒绝非规范 commit |

支持的 type: `feat | fix | chore | docs | refactor | perf | test | build | ci | release | revert`

### 安装

```bash
./common/git-hooks/install.sh
```

- 重复运行**幂等**(已存在且一致则跳过)
- 安装后会在 `.git/hooks/.installed-by-caep-infra-gcp-release` 写一个 marker 文件(用来 `--uninstall` 时识别)
- commit 时 hook 会在 stderr 打印失败原因,`git commit` 直接报错退出 1

### 卸载

```bash
./common/git-hooks/install.sh --uninstall
```

只删本脚本安装的(看 marker),不删 git 自带的 `*.sample` hooks。

### 跳过(临时)

```bash
git commit --no-verify -m "..."  # 跳过 commit-msg hook(不推荐)
```

### 跳过的场景

`commit-msg` hook 自动放过两类消息(不阻断):
- `Merge ...` 开头的合并 commit
- `Revert "..."` 开头的回滚 commit

### 为什么 hooks 在 common/ 下,不在 .git/hooks/

- `.git/hooks/` 是 git 本地目录,commit 不入仓,丢了找不回
- 放在 `common/git-hooks/` 后,跟其他工具脚本一起入仓,可重装、可审计、可跨机器同步
- 装/卸统一由 `install.sh` 管理,marker 识别防误删

---

## 提交流程

1. 新增 lib 函数 → 在当前文件追加,**不要**新建 `lib-xxx-v2.sh` 之类。
2. 改函数签名 → 同步更新所有 release 的脚本(grep 一下)。
3. 改函数 body → body 内部变更**不**算 breaking change,但要在 `docs/ai-collaboration.md` 记录。
