#!/usr/bin/env bash
# =============================================================
# common/git-hooks/install.sh — 安装本仓库的 git hooks 到 .git/hooks/
#
# 用法:
#   ./common/git-hooks/install.sh            # 安装所有 hooks
#   ./common/git-hooks/install.sh --uninstall  # 卸载(删除我们安装的)
#
# 设计:
#   - 本仓库的 git hooks 放在 common/git-hooks/ 下,可入仓、可版本化
#   - .git/hooks/ 不入仓,install.sh 一次性同步
#   - 重复运行是幂等的(覆盖前会对比,相同则跳过)
#   - 卸载时只删除本脚本安装的(不删 git 自带的 *.sample)
# =============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
HOOKS_SRC="${SCRIPT_DIR}"
HOOKS_DST="${ROOT_DIR}/.git/hooks"

log() { echo "  $*"; }
die() { echo "❌  $*" >&2; exit 1; }

[[ -d "$HOOKS_DST" ]] || die ".git/hooks/ 不存在 (当前目录不是 git repo?请在仓库根跑)"

# ---------- 解析参数 ----------
ACTION="install"
for arg in "$@"; do
    case "$arg" in
        --uninstall) ACTION="uninstall" ;;
        --help|-h)
            cat <<EOF
用法: $0 [--uninstall]

默认:  install — 把 common/git-hooks/* 复制到 .git/hooks/
        --uninstall — 删除 .git/hooks/ 里本仓库安装的 hooks

注意: 只删本脚本安装的(用我们的 marker 'installed by caep-infra-gcp-release'
识别),不删 git 自带的 *.sample。
EOF
            exit 0
            ;;
    esac
done

# ---------- 列出本仓库的 hooks ----------
# 用本脚本自身在 .git/hooks/ 里的存在作为锚点(或者用 marker 文件 .installed-by-caep-infra)
MARKER="${HOOKS_DST}/.installed-by-caep-infra-gcp-release"

OUR_HOOKS=()
for src in "${HOOKS_SRC}"/*; do
    [[ -f "$src" ]] || continue
    name="$(basename "$src")"
    [[ "$name" == "install.sh" ]] && continue   # 跳过自身
    OUR_HOOKS+=("$name")
done

if [[ ${#OUR_HOOKS[@]} -eq 0 ]]; then
    die "common/git-hooks/ 下没有任何 hook 文件 (除 install.sh 外)"
fi

# ---------- install ----------
if [[ "$ACTION" == "install" ]]; then
    echo "==> 安装 ${#OUR_HOOKS[@]} 个 hook 到 ${HOOKS_DST}/"
    for name in "${OUR_HOOKS[@]}"; do
        src="${HOOKS_SRC}/${name}"
        dst="${HOOKS_DST}/${name}"
        if [[ -f "$dst" ]] && diff -q "$src" "$dst" >/dev/null 2>&1; then
            log "⏭  $name 已存在且一致,跳过"
        else
            cp "$src" "$dst"
            chmod +x "$dst"
            log "✅ $name 已安装"
        fi
    done
    # 写 marker
    date -u '+%Y-%m-%dT%H:%M:%SZ' > "$MARKER"
    log "📌 marker: $MARKER"

    echo ""
    echo "✅ 全部 hooks 已安装。验证:"
    for name in "${OUR_HOOKS[@]}"; do
        dst="${HOOKS_DST}/${name}"
        if [[ -x "$dst" ]]; then
            log "  $dst  (可执行)"
        else
            log "  $dst  ❌ 不可执行"
        fi
    done

# ---------- uninstall ----------
elif [[ "$ACTION" == "uninstall" ]]; then
    echo "==> 卸载本仓库安装的 hooks"
    if [[ ! -f "$MARKER" ]]; then
        log "⚠️  没找到 marker $MARKER — 本仓库可能没装过 hooks,跳过"
        exit 0
    fi
    for name in "${OUR_HOOKS[@]}"; do
        dst="${HOOKS_DST}/${name}"
        if [[ -f "$dst" ]]; then
            rm -f "$dst"
            log "🗑  $name 已删除"
        fi
    done
    rm -f "$MARKER"
    log "📌 marker 已删除"
    echo ""
    echo "✅ 卸载完成"
fi
