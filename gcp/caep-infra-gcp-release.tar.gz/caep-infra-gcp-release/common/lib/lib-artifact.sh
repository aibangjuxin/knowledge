#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_ARTIFACT_VERSION="0.1.0"
# =============================================================
# lib-artifact.sh — 资源描述快照落盘 (gcloud describe → JSON)
# =============================================================
# 封装:
#   - gcloud <resource> describe --format=json → <file>
#   - 自动确保 artifacts/ 目录存在
#   - 失败容忍(资源不存在时只 WARN,不 fail)
# 用途:
#   - release/setup-<region>.sh 跑完后,把所有新建资源的 describe 输出
#     存到 artifacts/ 目录,作为 audit trail
# =============================================================

LIB_ARTIFACT_VERSION="0.1.0"

[[ -n "${_LIB_ARTIFACT_LOADED:-}" ]] && return 0
_LIB_ARTIFACT_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# -------------------------------------------------------------
# _artifact_capture <output_file> <description> <gcloud_args...>
#   跑 gcloud <args> --format=json,把输出写到 output_file
#   失败时(WARN 而非 fail,用于已删除资源的回填场景)
#   例:
#     _artifact_capture artifacts/uk-bucket.json "UK artifacts bucket" \
#         storage buckets describe gs://caep-uk-core-artifacts \
#         --project="$PROJECT_CORE"
# -------------------------------------------------------------
_artifact_capture() {
    local output_file="$1"
    local desc="$2"
    shift 2

    if [[ -z "$output_file" || -z "$desc" || $# -lt 1 ]]; then
        _log_error "_artifact_capture: usage: _artifact_capture <output_file> <desc> <gcloud args...>"
        return 1
    fi

    # 自动 mkdir -p
    local out_dir
    out_dir=$(dirname "$output_file")
    [[ ! -d "$out_dir" ]] && mkdir -p "$out_dir"

    # 找 --format 参数,如已有则用,否则补 --format=json
    local args=("$@")
    local has_format=false
    for a in "${args[@]}"; do
        [[ "$a" == "--format"* ]] && has_format=true && break
    done
    $has_format || args+=("--format=json")

    _log_info "捕获 ${desc} → ${output_file}"
    if ! gcloud "${args[@]}" > "$output_file" 2>/dev/null; then
        _log_warn "捕获失败(资源可能不存在): ${desc} → ${output_file}"
        # 留空文件 + metadata,便于审计
        echo "{\"_capture_failed\": true, \"_description\": \"${desc}\", \"_gcloud_args\": $(printf '%s\n' "${args[@]}" | jq -R . | jq -s .), \"_captured_at\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" > "$output_file"
        return 0
    fi
    return 0
}

# -------------------------------------------------------------
# _artifact_capture_batch <output_dir> <gcloud_resource_type> <project_id>
#   批量捕获某 project 下某类资源的所有实例
#   例:
#     _artifact_capture_batch artifacts/uk/ storage buckets "$PROJECT_CORE"
#     # → artifacts/uk/storage-bucket-<name>.json
#   返回捕获的文件数
# -------------------------------------------------------------
_artifact_capture_batch() {
    local output_dir="$1" resource_type="$2" project="$3"
    [[ -z "$output_dir" || -z "$resource_type" || -z "$project" ]] && {
        _log_error "_artifact_capture_batch: usage: _artifact_capture_batch <output_dir> <resource_type> <project>"
        return 1
    }

    [[ ! -d "$output_dir" ]] && mkdir -p "$output_dir"

    local list_output
    list_output=$(gcloud "$resource_type" list --project="$project" --format=json 2>/dev/null) || {
        _log_warn "_artifact_capture_batch: gcloud ${resource_type} list 失败 (project=${project})"
        return 0
    }

    local count
    count=$(echo "$list_output" | jq 'length' 2>/dev/null || echo 0)
    _log_info "批量捕获 ${count} 个 ${resource_type} 到 ${output_dir}/"
    echo "$list_output" | jq -c '.[]' 2>/dev/null | while IFS= read -r item; do
        local name
        name=$(echo "$item" | jq -r '.name' 2>/dev/null)
        [[ -z "$name" || "$name" == "null" ]] && continue
        # 把 name 里的 "/" 换成 "_" 以保证文件名合法
        local safe_name="${name//\//_}"
        echo "$item" > "${output_dir}/${resource_type// /-}-${safe_name}.json"
    done
    return 0
}
