#!/opt/homebrew/bin/bash
# =============================================================
# lib-assert.sh — 资源存在 / PASS/FAIL 累计断言
# =============================================================
# 封装:
#   - _assert_resource_exists <desc> <check_cmd>     资源类
#   - _assert_eq / _assert_ne / _assert_nonempty      值类
#   - _assert_pass_count / _assert_fail_count        累计
#   - 退出码聚合
# 设计:
#   - 故意不开 set -e(verify 脚本需要把每项都跑完)
#   - 用 captured-rc 模式($rc 变量)替代 -e
#   - bash 5 特性:用 declare -a 全局数组存 PASS/FAIL 列表
#     (替代 bash 3.2 兼容的空格分隔字符串)
# =============================================================

LIB_ASSERT_VERSION="0.1.1"  # bumped: switch internal storage to bash 5 arrays

[[ -n "${_LIB_ASSERT_LOADED:-}" ]] && return 0
_LIB_ASSERT_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# 累计计数器 + bash 5 全局数组
# _ASSERT_RESULTS_PASS[i] / _ASSERT_RESULTS_FAIL[i] 各自存 desc
_ASSERT_PASS_COUNT="${_ASSERT_PASS_COUNT:-0}"
_ASSERT_FAIL_COUNT="${_ASSERT_FAIL_COUNT:-0}"
# bash 5: 顶层 declare -a 即全局。函数内引用 + 累加用 _ASSERT_RESULTS_PASS+=(...)
# (不用 declare -g — 它是 ksh 扩展,GNU bash 不支持)
declare -a _ASSERT_RESULTS_PASS=()
declare -a _ASSERT_RESULTS_FAIL=()

# -------------------------------------------------------------
# _assert_pass <description>
#   记录一次 pass,内部用 bash 5 数组存储
# -------------------------------------------------------------
_assert_pass() {
    local desc="$1"
    _ASSERT_PASS_COUNT=$((_ASSERT_PASS_COUNT + 1))
    _ASSERT_RESULTS_PASS+=("${desc}")
    _log_info "✅ ${desc}"
}

# -------------------------------------------------------------
# _assert_fail <description>
#   记录一次 fail,内部用 bash 5 数组存储
# -------------------------------------------------------------
_assert_fail() {
    local desc="$1"
    _ASSERT_FAIL_COUNT=$((_ASSERT_FAIL_COUNT + 1))
    _ASSERT_RESULTS_FAIL+=("${desc}")
    _log_error "❌ ${desc}"
}

# -------------------------------------------------------------
# _assert_resource_exists <description> <check_function> [args...]
#   调 check_function,根据 echo 出的 "true"/"false" 判断
#   例:
#     _assert_resource_exists "bucket caep-uk-core-artifacts" \
#         _bucket_exists "$PROJECT_CORE" "caep-uk-core-artifacts"
# -------------------------------------------------------------
_assert_resource_exists() {
    local desc="$1"; shift
    local check_fn="$1"; shift

    if [[ -z "$desc" || -z "$check_fn" ]]; then
        _log_error "_assert_resource_exists: usage: _assert_resource_exists <desc> <check_fn> [args...]"
        return 1
    fi

    local result
    if ! result=$("$check_fn" "$@" 2>/dev/null); then
        _assert_fail "${desc} (check_fn ${check_fn} 执行失败)"
        return 1
    fi

    if [[ "$result" == "true" ]]; then
        _assert_pass "${desc}"
        return 0
    else
        _assert_fail "${desc} (${check_fn} 返回 ${result:-empty})"
        return 1
    fi
}

# -------------------------------------------------------------
# _assert_eq <description> <expected> <actual>
#   字符串相等断言
# -------------------------------------------------------------
_assert_eq() {
    local desc="$1" expected="$2" actual="$3"
    if [[ "$expected" == "$actual" ]]; then
        _assert_pass "${desc} (== '${expected}')"
        return 0
    else
        _assert_fail "${desc} (expected '${expected}', got '${actual}')"
        return 1
    fi
}

# -------------------------------------------------------------
# _assert_nonempty <description> <value>
#   值非空断言
# -------------------------------------------------------------
_assert_nonempty() {
    local desc="$1" value="$2"
    if [[ -n "$value" ]]; then
        _assert_pass "${desc} (= '${value}')"
        return 0
    else
        _assert_fail "${desc} (值为空)"
        return 1
    fi
}

# -------------------------------------------------------------
# _assert_summary
#   打印所有累计结果摘要,落盘到 $ARTIFACT_DIR/<prefix>-assert-*.log
#   bash 5: 用 "${ARR[@]}" 引号展开,支持 desc 里含空格
# -------------------------------------------------------------
_assert_summary() {
    local log_prefix="${1:-assert}"
    local timestamp
    timestamp=$(date +%Y%m%d-%H%M%S)

    _log_section "Assert Summary"
    _log_info "PASS: ${_ASSERT_PASS_COUNT}"
    _log_info "FAIL: ${_ASSERT_FAIL_COUNT}"
    _log_info "TOTAL: $((_ASSERT_PASS_COUNT + _ASSERT_FAIL_COUNT))"

    if [[ -n "${ARTIFACT_DIR:-}" && -d "${ARTIFACT_DIR}" ]]; then
        local log_file="${ARTIFACT_DIR}/${log_prefix}-assert-${timestamp}.log"
        {
            echo "Assert Summary — $(date -Iseconds)"
            echo "================================"
            echo "PASS: ${_ASSERT_PASS_COUNT}"
            echo "FAIL: ${_ASSERT_FAIL_COUNT}"
            echo "TOTAL: $((_ASSERT_PASS_COUNT + _ASSERT_FAIL_COUNT))"
            echo "================================"
            # bash 5 数组展开 — 安全处理含空格的 desc
            for d in "${_ASSERT_RESULTS_PASS[@]}"; do
                echo "PASS: ${d}"
            done
            for d in "${_ASSERT_RESULTS_FAIL[@]}"; do
                echo "FAIL: ${d}"
            done
        } > "$log_file"
        _log_info "结果已落盘: ${log_file}"
    fi

    return $((_ASSERT_FAIL_COUNT > 0 ? 1 : 0))
}

# -------------------------------------------------------------
# _assert_exit_code
#   便捷函数: 有 fail 就 exit 1,否则 exit 0
# -------------------------------------------------------------
_assert_exit_code() {
    [[ $_ASSERT_FAIL_COUNT -eq 0 ]]
}
