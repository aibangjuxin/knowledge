#!/opt/homebrew/bin/bash
# =============================================================
# lib-bash-version.sh — bash 5+ 推荐 guard
# =============================================================
# 在 lib 或 release 脚本顶部 source 此文件,提示用户升级到 bash 5。
# 不强制 exit(因为有些场景仍可在 bash 3.2 下工作,只是少部分功能)。
# 想强制的话:把下面的 exit 1 取消注释。
# =============================================================

[[ -n "${_LIB_BASH_VERSION_LOADED:-}" ]] && return 0
_LIB_BASH_VERSION_LOADED=1

if [[ "${BASH_VERSINFO[0]:-0}" -lt 5 ]]; then
    echo "⚠️  WARNING: bash ${BASH_VERSION:-unknown} < 5.0 — 本仓库脚本推荐用 bash 5+" >&2
    echo "   缺失特性: \${var^^}、mapfile、关联数组 等" >&2
    echo "   解法: macOS 'brew install bash',Linux 装 bash 5 包" >&2
    echo "   所有 .sh 已锁定到 /opt/homebrew/bin/bash,如还看到此警告,检查 PATH" >&2
    # 想强制失败请取消下行注释:
    # exit 1
fi
