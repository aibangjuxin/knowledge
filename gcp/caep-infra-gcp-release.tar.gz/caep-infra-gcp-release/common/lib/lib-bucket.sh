#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_BUCKET_VERSION="0.1.0"
# =============================================================
# lib-bucket.sh — GCS (Cloud Storage) 操作封装
# =============================================================
# 强制: 所有函数都接 PROJECT_ID,$BUCKET_NAME 来自调用方传入。
# 禁止: 在 lib 内部硬编码 bucket 名 / project ID / region。
# =============================================================

[[ -n "${_LIB_BUCKET_LOADED:-}" ]] && return 0
_LIB_BUCKET_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# -------------------------------------------------------------
# _bucket_exists <project_id> <bucket_name>
#   echo "true" | "false"
#   return 0 on success (无论 true/false), return 2 on gcloud 失败
# -------------------------------------------------------------
_bucket_exists() {
    local project="$1" bucket="$2"
    [[ -z "$project" || -z "$bucket" ]] && { _log_error "_bucket_exists: missing args"; return 1; }
    local out
    if ! out=$(gcloud storage buckets describe "gs://${bucket}" --project="$project" --format=json 2>/dev/null); then
        echo "false"
        return 0
    fi
    if echo "$out" | jq -e '.name' >/dev/null 2>&1; then
        echo "true"
    else
        echo "false"
    fi
    return 0
}

# -------------------------------------------------------------
# _bucket_create <project_id> <bucket_name> <location> [storage_class]
#   location: e.g. "EUROPE-WEST2" or "ASIA"
# -------------------------------------------------------------
_bucket_create() {
    local project="$1" bucket="$2" location="$3" class="${4:-STANDARD}"
    [[ -z "$project" || -z "$bucket" || -z "$location" ]] && {
        _log_error "_bucket_create: usage: _bucket_create <project> <bucket> <location> [class]"
        return 1
    }
    if [[ "$(_bucket_exists "$project" "$bucket")" == "true" ]]; then
        _log_info "bucket gs://${bucket} 已存在,跳过创建"
        return 0
    fi
    _log_info "创建 bucket gs://${bucket} (location=${location}, class=${class})"
    gcloud storage buckets create "gs://${bucket}" \
        --project="$project" \
        --location="$location" \
        --uniform-bucket-level-access \
        --default-storage-class="$class" \
        --format=json | _log_json "bucket create result"
}

# -------------------------------------------------------------
# _bucket_ls <project_id> <bucket_name> [prefix]
#   echo 出对象列表 (JSON 数组)
# -------------------------------------------------------------
_bucket_ls() {
    local project="$1" bucket="$2" prefix="${3:-}"
    [[ -z "$project" || -z "$bucket" ]] && { _log_error "_bucket_ls: missing args"; return 1; }
    gcloud storage ls --project="$project" --format=json "gs://${bucket}/${prefix}"
}

# -------------------------------------------------------------
# _bucket_rm <project_id> <bucket_name> [--force-empty]
#   --force-empty: 先清空再删 (危险,谨慎使用)
# -------------------------------------------------------------
_bucket_rm() {
    local project="$1" bucket="$2" force="${3:-}"
    [[ -z "$project" || -z "$bucket" ]] && { _log_error "_bucket_rm: missing args"; return 1; }
    if [[ "$force" == "--force-empty" ]]; then
        _log_warn "force-empty 模式:将清空 gs://${bucket} 所有对象"
        gcloud storage rm --project="$project" --recursive "gs://${bucket}/*" || true
    fi
    gcloud storage buckets delete --project="$project" "gs://${bucket}"
}
