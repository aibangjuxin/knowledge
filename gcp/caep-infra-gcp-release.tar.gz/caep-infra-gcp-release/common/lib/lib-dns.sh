#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_DNS_VERSION="0.1.0"
# =============================================================
# lib-dns.sh — Cloud DNS 操作封装
# =============================================================

[[ -n "${_LIB_DNS_LOADED:-}" ]] && return 0
_LIB_DNS_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# -------------------------------------------------------------
# _dns_zone_exists <project_id> <zone_name>
# -------------------------------------------------------------
_dns_zone_exists() {
    local project="$1" zone="$2"
    [[ -z "$project" || -z "$zone" ]] && { _log_error "_dns_zone_exists: missing args"; return 1; }
    if gcloud dns managed-zones describe "$zone" --project="$project" --format=json 2>/dev/null | jq -e '.name' >/dev/null; then
        echo "true"
    else
        echo "false"
    fi
    return 0
}

# -------------------------------------------------------------
# _dns_record_set <project_id> <zone_name> <name> <type> <ttl> <rrdatas_csv>
#   rrdas_csv: 多个值用逗号分隔
#   type: A | AAAA | CNAME | TXT | CAA | SRV
# -------------------------------------------------------------
_dns_record_set() {
    local project="$1" zone="$2" name="$3" rtype="$4" ttl="$5" rrdatas="$6"
    [[ -z "$project" || -z "$zone" || -z "$name" || -z "$rtype" || -z "$ttl" || -z "$rrdatas" ]] && {
        _log_error "_dns_record_set: usage: _dns_record_set <project> <zone> <name> <type> <ttl> <rrdatas>"
        return 1
    }
    _log_info "设置 DNS 记录: ${name}.${zone} ${rtype} ${ttl} ${rrdatas}"
    # 转 CSV → JSON 数组
    local rrdatas_json
    rrdatas_json=$(echo "$rrdatas" | jq -R 'split(",")')

    local tmpfile
    tmpfile=$(mktemp)
    cat > "$tmpfile" <<EOF
{
  "deletions": [],
  "additions": [
    {
      "name": "${name}",
      "type": "${rtype}",
      "ttl": ${ttl},
      "rrdatas": ${rrdatas_json}
    }
  ]
}
EOF
    gcloud dns record-sets transaction start --project="$project" --zone="$zone" 2>/dev/null || true
    gcloud dns record-sets transaction add "${name}.${zone}." "${rtype}" "${ttl}" ${rrdatas//,/ } \
        --project="$project" --zone="$zone" 2>/dev/null
    gcloud dns record-sets transaction execute --project="$project" --zone="$zone"
    rm -f "$tmpfile"
}

# -------------------------------------------------------------
# _dns_record_rm <project_id> <zone_name> <name> <type>
# -------------------------------------------------------------
_dns_record_rm() {
    local project="$1" zone="$2" name="$3" rtype="$4"
    [[ -z "$project" || -z "$zone" || -z "$name" || -z "$rtype" ]] && { _log_error "_dns_record_rm: missing args"; return 1; }
    gcloud dns record-sets delete "${name}.${zone}." --type="$rtype" --project="$project" --zone="$zone"
}
