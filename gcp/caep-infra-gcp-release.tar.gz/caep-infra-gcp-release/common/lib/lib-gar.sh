#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_GAR_VERSION="0.1.0"
# =============================================================
# lib-gar.sh — Artifact Registry 操作封装
# =============================================================

[[ -n "${_LIB_GAR_LOADED:-}" ]] && return 0
_LIB_GAR_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# -------------------------------------------------------------
# _gar_repo_exists <project_id> <location> <repo_name>
# -------------------------------------------------------------
_gar_repo_exists() {
    local project="$1" location="$2" repo="$3"
    [[ -z "$project" || -z "$location" || -z "$repo" ]] && { _log_error "_gar_repo_exists: missing args"; return 1; }
    if gcloud artifacts repositories describe "$repo" --project="$project" --location="$location" --format=json 2>/dev/null | jq -e '.name' >/dev/null; then
        echo "true"
    else
        echo "false"
    fi
    return 0
}

# -------------------------------------------------------------
# _gar_repo_create <project_id> <location> <repo_name> <format>
#   format: DOCKER | MAVEN | NPM | PYTHON | GO
# -------------------------------------------------------------
_gar_repo_create() {
    local project="$1" location="$2" repo="$3" format="$4"
    [[ -z "$project" || -z "$location" || -z "$repo" || -z "$format" ]] && {
        _log_error "_gar_repo_create: usage: _gar_repo_create <project> <location> <repo> <format>"
        return 1
    }
    if [[ "$(_gar_repo_exists "$project" "$location" "$repo")" == "true" ]]; then
        _log_info "GAR repo ${repo} (${location}) 已存在,跳过"
        return 0
    fi
    _log_info "创建 GAR repo ${repo} (${location}, ${format})"
    gcloud artifacts repositories create "$repo" \
        --project="$project" \
        --location="$location" \
        --repository-format="$format" \
        --description="created by caep-infra release" \
        --format=json | _log_json "gar repo create"
}

# -------------------------------------------------------------
# _gar_image_ls <project_id> <location> <repo_name>
#   返回 image 列表 (JSON 数组)
# -------------------------------------------------------------
_gar_image_ls() {
    local project="$1" location="$2" repo="$3"
    [[ -z "$project" || -z "$location" || -z "$repo" ]] && { _log_error "_gar_image_ls: missing args"; return 1; }
    gcloud artifacts docker images list \
        --project="$project" \
        "projects/${project}/locations/${location}/repositories/${repo}" \
        --format=json
}
