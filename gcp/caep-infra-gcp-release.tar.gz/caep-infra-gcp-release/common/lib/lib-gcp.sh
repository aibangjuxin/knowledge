#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_GCP_VERSION="0.1.0"
# =============================================================
# lib-gcp.sh — 跨 gcloud 命令的公共上下文工具
# =============================================================
# 封装:
#   - gcloud auth 状态检查
#   - gcloud projects describe (project access check)
#   - project ID 格式校验
#   - 公共 gcloud config setter
# 不封装:
#   - 任何资源操作(那是 lib-bucket / lib-gar / lib-iam 等的事)
# =============================================================

# 版本: 遵循 semver。lib 升级 SemVer 时:
#   - MAJOR: 函数签名变 / 删除函数 / 行为不兼容
#   - MINOR: 新增函数 / 新增可选参数
#   - PATCH: bug 修复 / 注释更新
LIB_GCP_VERSION="0.1.0"

[[ -n "${_LIB_GCP_LOADED:-}" ]] && return 0
_LIB_GCP_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# -------------------------------------------------------------
# _gcp_require_auth
#   检查 gcloud 是否已登录,失败时 _log_die
#   退出码: 0 = 已登录
# -------------------------------------------------------------
_gcp_require_auth() {
    if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | grep -q .; then
        _log_die "gcloud 未登录,请先跑 'gcloud auth login' 或在跳板机上 'gcloud auth activate-service-account'"
    fi
    local account
    account=$(gcloud auth list --filter=status:ACTIVE --format="value(account)" 2>/dev/null | head -1)
    _log_info "gcloud 已登录为: ${account}"
}

# -------------------------------------------------------------
# _gcp_require_project_access <project_id>
#   检查当前身份有 project 的 access,失败时 _log_die
#   退出码: 0 = 有 access
# -------------------------------------------------------------
_gcp_require_project_access() {
    local project="$1"
    [[ -z "$project" ]] && { _log_error "_gcp_require_project_access: missing project_id"; return 1; }
    if ! gcloud projects describe "$project" --format=json >/dev/null 2>&1; then
        _log_die "没有 project ${project} 的 access。请检查: (1) gcloud auth 身份 (2) IAM role (需要至少 roles/viewer)"
    fi
    _log_info "project ${project} access OK"
}

# -------------------------------------------------------------
# _gcp_validate_project_id <project_id>
#   校验格式是否符合 GCP project ID 规则:
#     6-30 字符,以小写字母开头,只能含小写字母、数字、短横线
#   退出码: 0 = 合法, 1 = 非法
# -------------------------------------------------------------
_gcp_validate_project_id() {
    local project="$1"
    if [[ -z "$project" ]]; then
        _log_error "_gcp_validate_project_id: missing project_id"
        return 1
    fi
    if [[ ! "$project" =~ ^[a-z][-a-z0-9]{4,28}[a-z0-9]$ ]]; then
        _log_error "project_id '${project}' 格式不合法 (期望 6-30 字符,以小写字母开头,只含 [a-z0-9-])"
        return 1
    fi
    return 0
}

# -------------------------------------------------------------
# _gcp_set_config <key> <value> [gcloud_config_name]
#   gcloud config set 的统一入口,带日志
#   例: _gcp_set_config "compute/region" "europe-west2"
# -------------------------------------------------------------
_gcp_set_config() {
    local key="$1" value="$2" config_name="${3:-}"
    if [[ -z "$key" || -z "$value" ]]; then
        _log_error "_gcp_set_config: usage: _gcp_set_config <key> <value> [config_name]"
        return 1
    fi
    _log_debug "gcloud config set ${key}=${value}${config_name:+ (in $config_name)}"
    if [[ -n "$config_name" ]]; then
        gcloud config set "$key" "$value" --configuration="$config_name" >/dev/null
    else
        gcloud config set "$key" "$value" >/dev/null
    fi
}
