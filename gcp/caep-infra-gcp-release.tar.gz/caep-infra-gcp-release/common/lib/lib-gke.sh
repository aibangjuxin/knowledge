#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_GKE_VERSION="0.1.0"
# =============================================================
# lib-gke.sh — GKE 集群操作封装
# =============================================================

[[ -n "${_LIB_GKE_LOADED:-}" ]] && return 0
_LIB_GKE_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# -------------------------------------------------------------
# _gke_cluster_exists <project_id> <location> <cluster_name>
#   location 可为 region(如 europe-west2)或 zone
# -------------------------------------------------------------
_gke_cluster_exists() {
    local project="$1" location="$2" cluster="$3"
    [[ -z "$project" || -z "$location" || -z "$cluster" ]] && { _log_error "_gke_cluster_exists: missing args"; return 1; }
    if gcloud container clusters describe "$cluster" --project="$project" --location="$location" --format=json 2>/dev/null | jq -e '.name' >/dev/null; then
        echo "true"
    else
        echo "false"
    fi
    return 0
}

# -------------------------------------------------------------
# _gke_get_credentials <project_id> <location> <cluster_name>
#   把 kubeconfig 写到 ~/.kube/config (默认)
# -------------------------------------------------------------
_gke_get_credentials() {
    local project="$1" location="$2" cluster="$3"
    [[ -z "$project" || -z "$location" || -z "$cluster" ]] && { _log_error "_gke_get_credentials: missing args"; return 1; }
    _log_info "拉取 GKE 凭据: ${cluster} @ ${location} (project=${project})"
    gcloud container clusters get-credentials "$cluster" \
        --project="$project" --location="$location"
}

# -------------------------------------------------------------
# _gke_kubectl <project_id> <location> <cluster_name> -- <kubectl args...>
#   内部封装,先 get-credentials 再 kubectl
# -------------------------------------------------------------
_gke_kubectl() {
    local project="$1" location="$2" cluster="$3"
    shift 3
    [[ "$1" == "--" ]] && shift
    _gke_get_credentials "$project" "$location" "$cluster" || return 1
    kubectl "$@"
}
