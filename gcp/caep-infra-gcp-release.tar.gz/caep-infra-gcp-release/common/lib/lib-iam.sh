#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_IAM_VERSION="0.1.0"
# =============================================================
# lib-iam.sh — IAM / Service Account 操作封装
# =============================================================

[[ -n "${_LIB_IAM_LOADED:-}" ]] && return 0
_LIB_IAM_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# -------------------------------------------------------------
# _iam_sa_exists <project_id> <sa_email>
# -------------------------------------------------------------
_iam_sa_exists() {
    local project="$1" sa="$2"
    [[ -z "$project" || -z "$sa" ]] && { _log_error "_iam_sa_exists: missing args"; return 1; }
    if gcloud iam service-accounts describe "$sa" --project="$project" --format=json 2>/dev/null | jq -e '.email' >/dev/null; then
        echo "true"
    else
        echo "false"
    fi
    return 0
}

# -------------------------------------------------------------
# _iam_sa_create <project_id> <sa_name> [display_name]
# -------------------------------------------------------------
_iam_sa_create() {
    local project="$1" sa_name="$2" display="${3:-}"
    [[ -z "$project" || -z "$sa_name" ]] && { _log_error "_iam_sa_create: missing args"; return 1; }
    local sa_email="${sa_name}@${project}.iam.gserviceaccount.com"
    if [[ "$(_iam_sa_exists "$project" "$sa_email")" == "true" ]]; then
        _log_info "SA ${sa_email} 已存在,跳过"
        return 0
    fi
    _log_info "创建 SA ${sa_email}"
    gcloud iam service-accounts create "$sa_name" \
        --project="$project" \
        ${display:+--display-name="$display"} \
        --format=json | _log_json "sa create"
}

# -------------------------------------------------------------
# _iam_sa_bind_role <project_id> <sa_email> <role>
#   role: roles/storage.admin / roles/cloudsql.client 等
# -------------------------------------------------------------
_iam_sa_bind_role() {
    local project="$1" sa="$2" role="$3"
    [[ -z "$project" || -z "$sa" || -z "$role" ]] && { _log_error "_iam_sa_bind_role: missing args"; return 1; }
    _log_info "给 ${sa} 绑 role ${role} (在 project ${project})"
    gcloud projects add-iam-policy-binding "$project" \
        --member="serviceAccount:${sa}" \
        --role="$role" \
        --format=json >/dev/null
}

# -------------------------------------------------------------
# _iam_sa_impersonate <sa_email>
#   把当前 gcloud 身份切换到 SA(用 IAMCredentials API,无需下载 key)
#   用法: eval "$(_iam_sa_impersonate foo@bar.iam.gserviceaccount.com)"
# -------------------------------------------------------------
_iam_sa_impersonate() {
    local sa="$1"
    [[ -z "$sa" ]] && { _log_error "_iam_sa_impersonate: missing sa"; return 1; }
    gcloud config set auth/impersonate_service_account "$sa"
}
