#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_JUMP_VERSION="0.1.0"
# =============================================================
# lib-jump.sh — 跳板机 IAP 隧道封装
# =============================================================
# 设计:
#   - 跳板机本身通过 IAP TCP forwarding 访问
#   - 跳板机上跑 gcloud / kubectl,本地不直接连 GCP API
#   - 本地只在跳板机上开 SSH session,不暴露额外端口
# =============================================================

[[ -n "${_LIB_JUMP_LOADED:-}" ]] && return 0
_LIB_JUMP_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# 跳板机配置(由 regions/<r>/env.sh 覆盖)
JUMPBOX_PROJECT="${JUMPBOX_PROJECT:-caep-shared-jumpbox}"
JUMPBOX_ZONE="${JUMPBOX_ZONE:-europe-west2-a}"
JUMPBOX_INSTANCE="${JUMPBOX_INSTANCE:-caep-jump-uk-01}"
JUMPBOX_USER="${JUMPBOX_USER:-lex_admin}"

# -------------------------------------------------------------
# _jump_ssh [extra ssh args...]
#   直连跳板机的便捷封装
#   等价于: gcloud compute ssh ${JUMPBOX_USER}@${JUMPBOX_INSTANCE} -- ...
# -------------------------------------------------------------
_jump_ssh() {
    _log_info "连跳板机 ${JUMPBOX_INSTANCE} (project=${JUMPBOX_PROJECT}, zone=${JUMPBOX_ZONE})"
    gcloud compute ssh "${JUMPBOX_USER}@${JUMPBOX_INSTANCE}" \
        --project="$JUMPBOX_PROJECT" \
        --zone="$JUMPBOX_ZONE" \
        -- "$@"
}

# -------------------------------------------------------------
# _jump_run <remote_command...>
#   在跳板机上跑单条命令,捕获输出
# -------------------------------------------------------------
_jump_run() {
    local cmd="$*"
    gcloud compute ssh "${JUMPBOX_USER}@${JUMPBOX_INSTANCE}" \
        --project="$JUMPBOX_PROJECT" \
        --zone="$JUMPBOX_ZONE" \
        --command="$cmd"
}

# -------------------------------------------------------------
# _jump_tunnel_open <local_port> <remote_host> <remote_port>
#   开 IAP TCP 隧道 (后台进程,记下 PID 用于 close)
#   echo 出 PID
# -------------------------------------------------------------
_jump_tunnel_open() {
    local local_port="$1" remote_host="$2" remote_port="$3"
    _log_info "开 IAP 隧道: localhost:${local_port} → ${remote_host}:${remote_port}"
    gcloud compute start-iap-tunnel "${JUMPBOX_INSTANCE}" \
        --project="$JUMPBOX_PROJECT" \
        --zone="$JUMPBOX_ZONE" \
        --local-host-port="localhost:${local_port}" \
        --dest-group="${remote_host}" \
        --dest-port="${remote_port}" \
        --verbosity=warning &
    echo $!
}

# -------------------------------------------------------------
# _jump_tunnel_close <pid>
# -------------------------------------------------------------
_jump_tunnel_close() {
    local pid="$1"
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
        kill "$pid" 2>/dev/null || true
        _log_info "已关闭 IAP 隧道 (pid=${pid})"
    fi
}
