#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_LOG_VERSION="0.1.0"
# =============================================================
# lib-log.sh
# -------------------------------------------------------------
# 日志基础设施。所有 lib / release 脚本都依赖此文件。
# 加载方式: source "$(dirname ${BASH_SOURCE[0]})/lib-log.sh"
# =============================================================

# 防止重复 source
[[ -n "${_LIB_LOG_LOADED:-}" ]] && return 0
_LIB_LOG_LOADED=1

# ---------- 颜色 (终端支持时启用) ----------
if [[ -t 1 ]] && command -v tput >/dev/null 2>&1 && [[ "$(tput colors 2>/dev/null || echo 0)" -ge 8 ]]; then
    _C_RESET='\033[0m'
    _C_RED='\033[31m'
    _C_YELLOW='\033[33m'
    _C_GREEN='\033[32m'
    _C_BLUE='\033[34m'
    _C_GRAY='\033[90m'
else
    _C_RESET='' _C_RED='' _C_YELLOW='' _C_GREEN='' _C_BLUE='' _C_GRAY=''
fi

# ---------- 日志级别 ----------
# 用法: _log_set_level DEBUG
_LOG_LEVEL="${_LOG_LEVEL:-INFO}"
_log_level_to_int() {
    case "$1" in
        DEBUG) echo 0 ;; INFO) echo 1 ;; WARN) echo 2 ;; ERROR) echo 3 ;;
        *) echo 1 ;;
    esac
}
_log_set_level() { _LOG_LEVEL="$1"; }

# ---------- 基础输出 ----------
# 所有 _log_* 函数:
#   - 自动加时间戳
#   - 写 stderr (INFO/DEBUG),写 stdout (其他)
#   - 颜色仅在交互终端启用
_log_ts() { date '+%Y-%m-%dT%H:%M:%S%z'; }

_log_info()  { [[ $(_log_level_to_int "$_LOG_LEVEL") -le 1 ]] && echo -e "${_C_GRAY}$(_log_ts)${_C_RESET} ${_C_BLUE}INFO${_C_RESET}  $*" >&2 || true; }
_log_debug() { [[ $(_log_level_to_int "$_LOG_LEVEL") -le 0 ]] && echo -e "${_C_GRAY}$(_log_ts)${_C_RESET} ${_C_GRAY}DEBUG${_C_RESET} $*" >&2 || true; }
_log_warn()  { echo -e "${_C_GRAY}$(_log_ts)${_C_RESET} ${_C_YELLOW}WARN${_C_RESET}  $*" >&2; }
_log_error() { echo -e "${_C_GRAY}$(_log_ts)${_C_RESET} ${_C_RED}ERROR${_C_RESET} $*" >&2; }

# ---------- 分隔符 ----------
_log_section() {
    local title="$1"
    echo "" >&2
    echo -e "${_C_GREEN}========== ${title} ==========${_C_RESET}" >&2
    echo "" >&2
}

# ---------- JSON 美化输出 ----------
# 用法: _log_json "$description" "$json_string"
_log_json() {
    local desc="$1" json="$2"
    if command -v jq >/dev/null 2>&1; then
        echo -e "${_C_GRAY}$(_log_ts)${_C_RESET} ${_C_BLUE}JSON${_C_RESET}  ${desc}:"
        echo "$json" | jq . 2>/dev/null || echo "$json"
    else
        echo -e "${_C_GRAY}$(_log_ts)${_C_RESET} ${_C_BLUE}JSON${_C_RESET}  ${desc}: ${json}"
    fi
}

# ---------- 退出控制 ----------
_log_die() {
    _log_error "$*"
    exit 1
}
