#!/opt/homebrew/bin/bash

# 版本: 遵循 semver (MAJOR.MINOR.PATCH)。改函数签名/删除函数 bump MAJOR,
# 新增函数/可选参数 bump MINOR,bug 修复/注释 bump PATCH
LIB_SECRET_VERSION="0.1.0"
# =============================================================
# lib-secret.sh — Secret Manager 操作封装
# =============================================================
# 注意: 本 lib 永远不打印 secret value,只确认存在/版本号。
# 调试时若需 value,用 _secret_get_and_log (默认禁用,需环境变量开启)。
# =============================================================

[[ -n "${_LIB_SECRET_LOADED:-}" ]] && return 0
_LIB_SECRET_LOADED=1

source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib-log.sh"

# 调试用:导出此变量 = 1 才允许打印 secret value
_SECRET_DEBUG="${_SECRET_DEBUG:-0}"

# -------------------------------------------------------------
# _secret_exists <project_id> <secret_name>
# -------------------------------------------------------------
_secret_exists() {
    local project="$1" secret="$2"
    [[ -z "$project" || -z "$secret" ]] && { _log_error "_secret_exists: missing args"; return 1; }
    if gcloud secrets describe "$secret" --project="$project" --format=json 2>/dev/null | jq -e '.name' >/dev/null; then
        echo "true"
    else
        echo "false"
    fi
    return 0
}

# -------------------------------------------------------------
# _secret_get <project_id> <secret_name> [version]
#   echo 出 value 到 stdout。**只在脚本内部管道用,绝不入日志。**
# -------------------------------------------------------------
_secret_get() {
    local project="$1" secret="$2" version="${3:-latest}"
    [[ -z "$project" || -z "$secret" ]] && { _log_error "_secret_get: missing args"; return 1; }
    gcloud secrets versions access "$version" --secret="$secret" --project="$project" 2>/dev/null
}

# -------------------------------------------------------------
# _secret_put <project_id> <secret_name> <value_file_or_string>
#   第三个参数:文件路径则读文件,- 读 stdin
# -------------------------------------------------------------
_secret_put() {
    local project="$1" secret="$2" value="$3"
    [[ -z "$project" || -z "$secret" || -z "$value" ]] && { _log_error "_secret_put: missing args"; return 1; }
    if [[ "$(_secret_exists "$project" "$secret")" == "false" ]]; then
        _log_info "创建 secret ${secret}"
        gcloud secrets create "$secret" --project="$project" --replication-policy=automatic --format=json >/dev/null
    else
        _log_info "secret ${secret} 已存在,添加新版本"
    fi
    if [[ "$value" == "-" ]]; then
        gcloud secrets versions add "$secret" --project="$project" --data-file=-
    elif [[ -f "$value" ]]; then
        gcloud secrets versions add "$secret" --project="$project" --data-file="$value"
    else
        echo -n "$value" | gcloud secrets versions add "$secret" --project="$project" --data-file=-
    fi
}

# -------------------------------------------------------------
# _secret_rm <project_id> <secret_name>
# -------------------------------------------------------------
_secret_rm() {
    local project="$1" secret="$2"
    [[ -z "$project" || -z "$secret" ]] && { _log_error "_secret_rm: missing args"; return 1; }
    gcloud secrets delete "$secret" --project="$project" --quiet
}
