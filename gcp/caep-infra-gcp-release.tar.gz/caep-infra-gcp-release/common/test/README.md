# =============================================================
# common/test/README.md — bats 测试说明
# =============================================================

# 跑测试

```bash
# 跑全部 .bats
bats common/test/

# 跑单个
bats common/test/test_lib-log.bats

# TAP 格式输出 (CI 友好)
bats --formatter tap common/test/

# 装依赖 (首次)
brew install bats-core
brew install bats-support bats-assert   # 可选,test_helper 自动 load
```

## 设计

- **mock gcloud**: `common/test/mocks/gcloud` 是一个 fake binary,
  接收环境变量 `GCLOUD_MOCK_BUCKETS` / `GCLOUD_MOCK_GAR_REPOS` /
  `GCLOUD_MOCK_SAS` / `GCLOUD_MOCK_SECRETS` 等"应有状态"列表,
  比对调用并返回对应结果。test 套件种这些变量,lib 函数会
  调到这个 fake 而不是真 gcloud。
- **test_helper.bash**: 每个 .bats `load test_helper`,自动把
  `common/test/mocks/gcloud` 放到 PATH 最前 + 设 REPO 变量 +
  加载 bats-support / bats-assert (如果系统装了)。
- **test 命名**: `test_lib-<name>.bats`,对应 lib 文件 `lib-<name>.sh`。

## 覆盖现状

| lib | 测试文件 | 状态 |
|------|---------|------|
| lib-log.sh | test_lib-log.bats | ✅ 8 tests |
| lib-bucket.sh | test_lib-bucket.bats | ✅ 6 tests |
| lib-assert.sh | test_lib-assert.bats | ✅ 10 tests |
| lib-gar.sh | (待写) | ⬜ |
| lib-secret.sh | (待写) | ⬜ |
| lib-dns.sh | (待写) | ⬜ |
| lib-iam.sh | (待写) | ⬜ |
| lib-gke.sh | (待写) | ⬜ |
| lib-jump.sh | (待写) | ⬜ |
| lib-gcp.sh | (待写) | ⬜ |
| lib-artifact.sh | (待写) | ⬜ |

## CI 集成 (未来)

```bash
bats --formatter junit --output /tmp/bats-junit common/test/
# 把 /tmp/bats-junit/*.xml 上传 GitHub Actions / GitLab CI
```

## 写新测试的 4 步模板

```bash
#!/usr/bin/env bats
load test_helper

setup() {
    source "${REPO}/common/lib/lib-xxx.sh"
}

@test "_xxx_function: 期望行为" {
    # Arrange
    export GCLOUD_MOCK_xxx="expected_value"

    # Act
    run _xxx_function "arg1" "arg2"

    # Assert
    [ "$status" -eq 0 ]
    [ "$output" = "expected" ]
}
```
