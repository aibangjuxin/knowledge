# =============================================================
# common/test/test_helper.bash — bats 共享 setup
# =============================================================
# 在每个 .bats 文件用 'load test_helper' 引入。
# 提供:
#   - REPO 变量:本仓库根路径
#   - PATH 把 mocks 目录放最前(让 lib 调 gcloud 时命中 fake)
#   - bats assert / load 标准库
# =============================================================

REPO="$(cd "$(dirname "$BATS_TEST_FILENAME")/../.." && pwd)"
export REPO

# 把 mock gcloud 放到最前
# BATS_TMPDIR = suite 级(在 test_helper load 时已设)
# BATS_TEST_TMPDIR = 单 test 级(在 test setup 时才设,load 时不可用)
MOCK_BIN="${BATS_TMPDIR}/bin"
mkdir -p "$MOCK_BIN"
cp "${REPO}/common/test/mocks/gcloud" "${MOCK_BIN}/gcloud"
chmod +x "${MOCK_BIN}/gcloud"
export PATH="${MOCK_BIN}:${PATH}"

# 验证 mock 真的在最前
if ! command -v gcloud >/dev/null 2>&1 || [[ "$(command -v gcloud)" != "${MOCK_BIN}/gcloud" ]]; then
    echo "FATAL: mock gcloud not on PATH" >&2
    return 1
fi

# 加载 bats-support / bats-assert (如果系统装了)
# brew install bats-support bats-assert 后才有
if [[ -f "/opt/homebrew/share/bats-support/load.bash" ]]; then
    load '/opt/homebrew/share/bats-support/load'
fi
if [[ -f "/opt/homebrew/share/bats-assert/load.bash" ]]; then
    load '/opt/homebrew/share/bats-assert/load'
fi

# 通用 setup: 重置 assert 计数器
setup() {
    : "${_ASSERT_PASS_COUNT:=0}"
    : "${_ASSERT_FAIL_COUNT:=0}"
    : "${_ASSERT_RESULTS:=}"
    export _ASSERT_PASS_COUNT _ASSERT_FAIL_COUNT _ASSERT_RESULTS
}
