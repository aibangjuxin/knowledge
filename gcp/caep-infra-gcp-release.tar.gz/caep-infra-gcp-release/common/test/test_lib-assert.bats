#!/usr/bin/env bats
# =============================================================
# test_lib-assert.bats — lib-assert.sh 单元测试
# =============================================================
# Cover _assert_pass / _assert_fail / _assert_eq / _assert_nonempty /
# _assert_resource_exists / _assert_exit_code
#
# Note: bats 1.13.0 has a known issue sanitizing CJK chars in
# test names, so all @test names are ASCII.
# =============================================================

load test_helper

setup() {
    source "${REPO}/common/lib/lib-log.sh"
    source "${REPO}/common/lib/lib-assert.sh"
    source "${REPO}/common/lib/lib-bucket.sh"
    # lib-assert 计数器是全局,需要每个 test 前清零
    _ASSERT_PASS_COUNT=0
    _ASSERT_FAIL_COUNT=0
    _ASSERT_RESULTS=""
}

@test "_assert_pass increments pass counter" {
    _assert_pass "first check"
    [ "${_ASSERT_PASS_COUNT}" = "1" ]
    [ "${_ASSERT_FAIL_COUNT}" = "0" ]
}

@test "_assert_fail increments fail counter" {
    _assert_fail "first failure"
    [ "${_ASSERT_FAIL_COUNT}" = "1" ]
    [ "${_ASSERT_PASS_COUNT}" = "0" ]
}

@test "_assert_eq passes when values are equal" {
    _assert_eq "version" "1.0.0" "1.0.0"
    [ "${_ASSERT_PASS_COUNT}" = "1" ]
    [ "${_ASSERT_FAIL_COUNT}" = "0" ]
}

@test "_assert_eq fails when values differ" {
    # Use a subshell + capture exit, since _assert_fail returns 1
    # which would fail the bats test before the [ ... ] assertion runs.
    run bash -c 'source "'"${REPO}"'/common/lib/lib-log.sh"; source "'"${REPO}"'/common/lib/lib-assert.sh"; _assert_eq "version" "1.0.0" "2.0.0"; echo COUNTER=$_ASSERT_FAIL_COUNT'
    [ "$status" -eq 0 ]
    [[ "$output" == *"COUNTER=1"* ]]
}

@test "_assert_nonempty passes for non-empty value" {
    _assert_nonempty "project" "caep-prod-uk-core"
    [ "${_ASSERT_PASS_COUNT}" = "1" ]
}

@test "_assert_nonempty fails for empty value" {
    # Use a subshell + capture exit, since _assert_fail returns 1
    # which would fail the bats test before the [ ... ] assertion runs.
    run bash -c 'source "'"${REPO}"'/common/lib/lib-log.sh"; source "'"${REPO}"'/common/lib/lib-assert.sh"; _assert_nonempty "project" ""; echo COUNTER=$_ASSERT_FAIL_COUNT'
    [ "$status" -eq 0 ]
    [[ "$output" == *"COUNTER=1"* ]]
}

@test "_assert_resource_exists passes when check_fn returns true" {
    export GCLOUD_MOCK_BUCKETS="caep-uk-core-artifacts"
    _assert_resource_exists "bucket" _bucket_exists "test-project" "caep-uk-core-artifacts"
    [ "${_ASSERT_PASS_COUNT}" = "1" ]
}

@test "_assert_resource_exists fails when check_fn returns false" {
    unset GCLOUD_MOCK_BUCKETS
    run bash -c 'source "'"${REPO}"'/common/lib/lib-log.sh"; source "'"${REPO}"'/common/lib/lib-assert.sh"; source "'"${REPO}"'/common/lib/lib-bucket.sh"; _assert_resource_exists "bucket" _bucket_exists "test-project" "caep-uk-core-artifacts"; echo COUNTER=$_ASSERT_FAIL_COUNT'
    [ "$status" -eq 0 ]
    [[ "$output" == *"COUNTER=1"* ]]
}

@test "_assert_exit_code returns 0 when no fails" {
    _assert_pass "a"
    _assert_pass "b"
    _assert_exit_code
}

@test "_assert_exit_code returns 1 when any fail" {
    _assert_pass "a"
    _assert_fail "b"
    ! _assert_exit_code
}

@test "bash 5: _ASSERT_RESULTS_PASS is a bash 5 array" {
    _assert_pass "x"
    # bash 5 关联 / 普通数组能 declare -p 显示类型
    run bash -c 'source "'"${REPO}"'/common/lib/lib-log.sh"; source "'"${REPO}"'/common/lib/lib-assert.sh"; _assert_pass "y"; declare -p _ASSERT_RESULTS_PASS'
    [ "$status" -eq 0 ]
    [[ "$output" == *"declare -a _ASSERT_RESULTS_PASS"* ]]
    [[ "$output" == *"\"y\""* ]]
}

@test "bash 5: desc containing spaces is preserved" {
    # Old impl used space-separated string, would break on desc with spaces
    _assert_pass "bucket name with spaces and stuff"
    [ "${_ASSERT_RESULTS_PASS[0]}" = "bucket name with spaces and stuff" ]
}

@test "bash 5: parallel arrays keep PASS and FAIL in separate lists" {
    _assert_pass "first pass"
    _assert_fail "first fail"
    _assert_pass "second pass"
    [ "${#_ASSERT_RESULTS_PASS[@]}" = "2" ]
    [ "${#_ASSERT_RESULTS_FAIL[@]}" = "1" ]
    [ "${_ASSERT_RESULTS_PASS[0]}" = "first pass" ]
    [ "${_ASSERT_RESULTS_PASS[1]}" = "second pass" ]
    [ "${_ASSERT_RESULTS_FAIL[0]}" = "first fail" ]
}
