#!/usr/bin/env bats
# =============================================================
# test_lib-bucket.bats — lib-bucket.sh 单元测试
# =============================================================
# Use the mock gcloud (via test_helper) to test:
#   - _bucket_exists: returns "true" / "false" based on env
#   - _bucket_create: idempotent skip if already exists
#   - arg validation: missing arg → return 1
# =============================================================

load test_helper

setup() {
    source "${REPO}/common/lib/lib-log.sh"
    source "${REPO}/common/lib/lib-bucket.sh"
}

@test "_bucket_exists: returns true when bucket in mock list" {
    export GCLOUD_MOCK_BUCKETS="caep-uk-core-artifacts caep-shared-logs"
    run _bucket_exists "test-project" "caep-uk-core-artifacts"
    [ "$status" -eq 0 ]
    [ "$output" = "true" ]
}

@test "_bucket_exists: returns false when bucket not in mock list" {
    export GCLOUD_MOCK_BUCKETS="caep-shared-logs"
    run _bucket_exists "test-project" "caep-uk-core-artifacts"
    [ "$status" -eq 0 ]
    [ "$output" = "false" ]
}

@test "_bucket_exists: returns false when mock list is empty" {
    unset GCLOUD_MOCK_BUCKETS
    run _bucket_exists "test-project" "caep-uk-core-artifacts"
    [ "$status" -eq 0 ]
    [ "$output" = "false" ]
}

@test "_bucket_exists: returns 1 when project_id is missing" {
    run _bucket_exists "" "caep-uk-core-artifacts"
    [ "$status" -eq 1 ]
}

@test "_bucket_exists: returns 1 when bucket_name is missing" {
    run _bucket_exists "test-project" ""
    [ "$status" -eq 1 ]
}

@test "_bucket_create: skips create when bucket already exists" {
    export GCLOUD_MOCK_BUCKETS="caep-uk-core-artifacts"
    run _bucket_create "test-project" "caep-uk-core-artifacts" "europe-west2" "STANDARD"
    [ "$status" -eq 0 ]
    [[ "$output" == *"已存在"* ]]
}

@test "_bucket_create: returns 1 on missing args" {
    run _bucket_create "" "bucket" "loc" "class"
    [ "$status" -eq 1 ]
    run _bucket_create "proj" "" "loc" "class"
    [ "$status" -eq 1 ]
    run _bucket_create "proj" "bucket" "" "class"
    [ "$status" -eq 1 ]
}
