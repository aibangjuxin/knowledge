#!/usr/bin/env bats
# =============================================================
# test_lib-log.bats — lib-log.sh 单元测试
# =============================================================
# Cover:
#   - _log_set_level: all 4 levels
#   - _log_info/warn/error: write to stderr
#   - _log_section: header
#   - _log_json: pretty-print (with jq)
#   - _log_die: write ERROR + exit 1
#   - source guard: re-source is no-op
#
# Note: bats 1.13.0 has a known issue sanitizing CJK chars in
# test names, so all @test names are ASCII. Comments are bilingual.
# =============================================================

load test_helper

setup() {
    source "${REPO}/common/lib/lib-log.sh"
}

@test "_log_set_level accepts DEBUG/INFO/WARN/ERROR" {
    run _log_set_level "DEBUG"
    [ "$status" -eq 0 ]
    run _log_set_level "ERROR"
    [ "$status" -eq 0 ]
    run _log_set_level "BOGUS"
    [ "$status" -eq 0 ]  # defaults to INFO
}

@test "_log_info writes to stderr and contains message" {
    run _log_info "test message"
    [ "$status" -eq 0 ]
    [[ "$output" == *"test message"* ]]
}

@test "_log_warn includes WARN label" {
    run _log_warn "warning test"
    [ "$status" -eq 0 ]
    [[ "$output" == *"WARN"* ]]
    [[ "$output" == *"warning test"* ]]
}

@test "_log_error includes ERROR label" {
    run _log_error "error test"
    [ "$status" -eq 0 ]
    [[ "$output" == *"ERROR"* ]]
    [[ "$output" == *"error test"* ]]
}

@test "_log_section includes title text" {
    run _log_section "My Section"
    [ "$status" -eq 0 ]
    [[ "$output" == *"My Section"* ]]
    [[ "$output" == *"=="* ]]
}

@test "_log_json pretty-prints when jq is available" {
    if ! command -v jq >/dev/null 2>&1; then
        skip "jq not installed"
    fi
    run _log_json "test key" '{"a": 1, "b": [2, 3]}'
    [ "$status" -eq 0 ]
    [[ "$output" == *"\"a\""* ]]
    [[ "$output" == *"test key"* ]]
}

@test "_log_die writes ERROR and exits 1" {
    run _log_die "fatal error"
    [ "$status" -eq 1 ]
    [[ "$output" == *"ERROR"* ]]
    [[ "$output" == *"fatal error"* ]]
}

@test "source guard prevents re-execution" {
    # _LIB_LOG_LOADED set on first source
    [ -n "${_LIB_LOG_LOADED:-}" ]
    [ "${_LIB_LOG_LOADED}" = "1" ]

    # Re-source should be a no-op (guard returns 0 early)
    source "${REPO}/common/lib/lib-log.sh"

    # Function still defined
    run type _log_info
    [ "$status" -eq 0 ]
    [[ "$output" == *"function"* ]]
}
