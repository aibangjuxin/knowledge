# docs/

跨 release 的方法论文档。

| 文件 | 用途 |
|------|------|
| [`architecture-overview.md`](./architecture-overview.md) | 5 Region × N Project 矩阵 + 跳板机拓扑 + 网络边界 |
| [`release-process.md`](./release-process.md) | release 完整流程 SOP (planning → close) |
| [`ai-collaboration.md`](./ai-collaboration.md) | AI 协作协议详解 (根 README 第 3 节的扩展) |
| [`cr-template.md`](./cr-template.md) | CR 回填模板 (Jira/ServiceNow 等不同系统适配) |
