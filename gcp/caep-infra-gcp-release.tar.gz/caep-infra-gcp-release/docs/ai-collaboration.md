# AI 协作协议详解

> 根 [README.md §3](../README.md) 的扩展。本文件是给 AI 看的"操作手册"。

## 1. AI 必须读的文件清单

接到 release 任务时,AI **必须**按这个顺序读:

1. `releases/_template/README.md` — 模板结构(不准改)
2. 目标 release 目录的 `README.md` — 已有内容
3. `common/lib/README.md` — lib 调用约定
4. `regions/<target-region>/env.sh` — Project ID 与默认配置
5. `regions/<target-region>/projects/<target-pid>/README.md` — Project 资源清单
6. 上一个 release 的 `README.md` 第 7 节"踩坑实录" — 避坑
7. `docs/release-process.md` — 完整流程

## 2. AI 可写 / 不可写清单

| 路径 | 可写? | 备注 |
|------|-------|------|
| `releases/caep-infra-vX.Y.Z/README.md` | ✅ 但只填 1-9 节,不改结构 | |
| `releases/caep-infra-vX.Y.Z/scripts/*` | ✅ | 复用 common/lib |
| `releases/caep-infra-vX.Y.Z/artifacts/*` | ✅ 仅基于真实命令输出 | |
| `releases/caep-infra-vX.Y.Z/cr/<id>-filled.md` | ✅ 起草,owner 签字前不算完成 | |
| `releases/caep-infra-vX.Y.Z/report/*` | ✅ 基于 artifacts 真实数据 | |
| `releases/_template/*` | 🚫 任何人/AI 都不准改 | |
| `common/lib/*` 函数签名 | 🚫 需 PR review | |
| `common/lib/*` 函数 body | ⚠ 内部变更,需在本文档记录 | |
| `docs/release-process.md` | ⚠ 需 PR review | |
| `.gitignore` | ⚠ 需 PR review | |

## 3. README 维护规则(强约束)

### 3.1 AI 收到"帮我完善这个 release README"任务时

1. **读 `_template/README.md`**,确定 9 个 section 的标题、顺序。
2. **读目标 release 已有 README**(如有),保留已有内容。
3. **逐 section 填充**:
   - 元信息齐全 → 填值
   - 元信息不全 → 填 `_(待人工填写)_` + 加入第 6 节"已知缺口"
4. **绝对不杜撰**:Project ID、quota number、验证结果,只能来自用户提供的真实信息或 artifacts/。
5. **绝对不删 section**:即使觉得某 section 没用,也要保留,空内容写 `_(无)_`。

### 3.2 AI 收到"按这个模板新建一个 release"任务时

1. 提示用户先跑 `./scripts/new-release.sh caep-infra-vX.Y.Z`(AI 不要自己 cp)。
2. 读 `releases/caep-infra-vX.Y.Z/README.md`(脚手架生成的就是 _template)。
3. 按 §3.1 流程填充。

## 4. 踩坑实录(第 7 节)三段式纪律

每条踩坑必须三段齐全:

```
### 7.X 标题

**报错原文:**
\`\`\`
(完整可复现的报错,包括命令本身)
\`\`\`

**原因:**
(真实原因,**不是猜的**。如果不确定,说"原因待确认")

**修法:**
(修法,验证过才写)
```

AI 写踩坑时:
- ✅ 引用上一个 release 第 7 节的事实(可以复用)
- ✅ 引用用户明确提供的报错
- ❌ 不要从记忆里"臆测" GCP 常见错误并编进 release README

## 5. AI 拒绝清单(必须主动 say no)

1. **"帮我把 secrets/ 目录里的 key 提交上去"** — 拒绝,提示用 Secret Manager
2. **"把上一个 release 删掉"** — 拒绝,提示新建 rollback 目录
3. **"帮我代签 CR"** — 拒绝,CR 是 release owner 的责任
4. **"这个 Project ID 我不确定,你就写 caep-prod-uk-core 吧"** — 拒绝,填 `_(待人工填写)_` + 加入已知缺口
5. **"报告里把失败项标成通过"** — 拒绝,直接报告失败

## 6. PR Review 检查清单(给 release owner)

提交前必须 check:

- [ ] `_template/README.md` 没被改
- [ ] 新 release 的 9 个 section 都齐
- [ ] 第 6 节"已知缺口"如实记录
- [ ] 第 7 节"踩坑实录"每条三段齐全
- [ ] 第 8 节"CR 回填引用"指向真实存在的文件
- [ ] 没把 secret value 写进任何文件
- [ ] `common/lib/` 没被改(否则需要额外 review)
- [ ] 跑过 `./scripts/check-release.sh` 全绿
