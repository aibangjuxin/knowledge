# Architecture Overview — 5 Region × N Project

> 维护者: Lex
> 最后更新: 仓库 init 时(等首次跑通后回填真实数据)

## 1. Region 矩阵

| Region | 显示名 | GCP Location | 合规框架 | 跳板机 | 主要 Project |
|--------|--------|--------------|----------|--------|-------------|
| UK | United Kingdom | europe-west2 | GDPR | caep-jump-uk-01 | caep-prod-uk-{core,data,net,log} |
| HK | Hong Kong | asia-east2 | PDPO | caep-jump-hk-01 | caep-prod-hk-{core,data} |
| IN | India | asia-south1 | DPDP | caep-jump-in-01 | caep-prod-in-{core,data} |
| CN | China Mainland | (partner) | (待定) | (partner 账号) | (待接入) |
| US | United States | us-central1 | CCPA | caep-jump-us-01 | caep-prod-us-{core,data,net} |

## 2. 网络拓扑

```
[Internet] ──┬── [Cloud DNS] ── [GLB] ── [GKE / Cloud Run]
             │
             └── [IAP] ── [Jumpbox] ── [GCP APIs (gcloud/kubectl)]
                                  │
                                  ├── UK  Jumpbox  ── europe-west2
                                  ├── HK  Jumpbox  ── asia-east2
                                  ├── IN  Jumpbox  ── asia-south1
                                  ├── CN  Jumpbox  ── (partner)
                                  └── US  Jumpbox  ── us-central1
```

- **对外:** Cloud DNS → GLB → 后端服务。Region 间走 GCP 全球 Anycast。
- **对内:** 所有 gcloud / kubectl 命令统一从跳板机发起。本地不暴露任何 GCP API 直连。

## 3. 跳板机工作流

### 3.1 为什么用跳板机

1. **审计:** 所有 GCP API 调用都从跳板机走,日志集中,便于合规审计。
2. **凭据隔离:** SA key 永远不下发到本地,跳板机用 IAMCredentials impersonation。
3. **网络边界:** 本地不直接连 GCP API,减少攻击面。

### 3.2 同步方式

- **当前(GitHub 接入前):** 手动 `rsync` 跳板机 ↔ 本仓库。
- **目标(接入后):** `./scripts/cr-sync.sh --release vX.Y.Z --pull` 自动同步 artifacts + report。
- **校验:** `./scripts/check-release.sh` 在跑 setup 前检查 `common/lib/` 与跳板机逐字一致。

## 4. Project 命名规范

```
caep-{env}-{region}-{purpose}
```

| 段 | 取值 | 例 |
|----|------|-----|
| env | prod / staging / dev | prod |
| region | uk / hk / in / cn / us | uk |
| purpose | core / data / net / log / shared | core |

例:`caep-prod-uk-core`、`caep-staging-hk-data`、`caep-shared-uk-jumpbox`。

## 5. 待办(等真实数据回填)

- [ ] 填入每个 Region 的真实 Project ID 列表
- [ ] 画 5 Region 完整网络拓扑图(用 creative/architecture-diagram skill)
- [ ] 填入每个 Project 的资源清单到 `regions/<r>/projects/<pid>/README.md`
- [ ] 跨 Region 流量走向(尤其 CN ↔ US 的合规桥接)
