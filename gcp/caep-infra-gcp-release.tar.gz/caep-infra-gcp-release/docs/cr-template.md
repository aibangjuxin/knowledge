# CR (Change Request) 回填模板

> 公司 CR 系统的回填内容模板。**具体格式依公司 CR 系统(Jira/ServiceNow/自研)调整。**
> AI 起草后由 release owner 复制到 CR 系统。

## 模板正文

```markdown
## Release: caep-infra-v<X.Y.Z>

**变更类型:** [新功能 / Bug 修复 / 基础设施变更]
**风险等级:** [低 / 中 / 高]
**变更窗口:** YYYY-MM-DD HH:MM ~ HH:MM (TZ)

### 变更摘要
(2-3 句话,说清这次 release 干了什么、为什么)

### 涉及范围
- Region: [ ] UK [ ] HK [ ] IN [ ] CN [ ] US
- Project: <列出所有 Project ID>
- 资源类型: GCS / GAR / IAM / Secret / DNS / GKE / ...

### 详细变更清单
(直接引用本 release README 第 2 节"变更范围"的内容)

### 风险与缓解
(直接引用本 release README 第 2.3 节的内容)

### 验证结果
(直接引用本 release README 第 5 节的内容,**用真实数据,不是预估**)

### 已知问题
(直接引用本 release README 第 6 节"已知缺口"的内容)

### 回滚计划
(直接引用本 release `scripts/rollback-*.sh` 的描述,说明回滚命令)

### 附件
- artifacts/<region>-*.json (资源描述快照)
- artifacts/<region>-verify-*.log
- report/report.html (HTML 报告)
- report/summary.md (一页纸总结)
```

## 不同 CR 系统的差异

| 系统 | 适配 |
|------|------|
| Jira | 把上面填到 description 字段,附件逐个上传 |
| ServiceNow | 同上,Change Request 表单 |
| 自研 Web | 通常有 markdown 渲染,直接粘贴 |
| 工单系统 + 邮件 | 邮件正文 markdown + 附件 zip |

## AI 起草流程

1. 读本 release 的 `README.md` 第 1-7 节
2. 把上面模板里的 `(引用 ...)` 替换成实际内容
3. 写进 `cr/<id>-filled.md`
4. **不**直接提交 CR 系统 — 由 release owner 复制粘贴

## 状态字段

| 状态 | 谁写 | 来源 |
|------|------|------|
| 待批准 | owner | 提交 CR 系统时由系统自动 |
| 已批准 | CR 系统 | owner 看到批准通知后从系统抄过来 |
| 执行中 | owner | 开始跑 setup 时 |
| 已完成 | owner | verify 全绿时 |
| 已关闭 | CR 系统 | 7 天观察期后 owner 关闭 |
