# Release Process — 端到端 SOP

> 本文档是 release 完整流程的标准操作程序。每个 release owner 在开工前必须读完本文件。

## Phase 1: Planning

**目标:** 明确这次 release 的范围、影响、风险。

1. **确定版本号** — 遵循 [根 README §2.1](../README.md) 的 semver 规则。
2. **确定涉及 Region + Project** — 检查 `regions/<r>/env.sh` 是否有所有需要操作的 Project。
3. **创建 CR 工单** — 模板见 [`cr-template.md`](./cr-template.md)。
4. **跑脚手架** — `./scripts/new-release.sh caep-infra-vX.Y.Z`。
5. **填新 release 的 README** — 按 [`_template/README.md`](../releases/_template/README.md) 填 1-3 节(元信息、变更范围、时间线)。
6. **拿到 CR 预批准** — 工单进入待审批状态(不等批准,先并行开发)。

## Phase 2: Preflight

**目标:** 在动手前把所有阻断项查出来。

7. **复制并写 `scripts/preflight-<region>.sh`** — 参考 `pfb-gcp-v0.1.0/scripts/preflight-uk.sh`。
8. **在跳板机上跑 preflight** — 任何失败立即停。
9. **更新 README 第 6 节"已知缺口"** — 把 preflight 暴露的问题记录进去。

## Phase 3: Execute

**目标:** 实际创建/更新/删除资源。

10. **写 `scripts/setup-<region>.sh`** — 复用 `common/lib/`,**禁止重写已有 lib 函数**。
11. **在跳板机上跑 setup** — 输出到 `artifacts/<region>-setup-<ts>.log`。
12. **收集资源描述快照** — `gcloud <resource> describe --format=json > artifacts/<region>-<resource>.json`。
13. **写 `scripts/verify-<region>.sh`** — 逐项校验。
14. **跑 verify** — 失败立即进入 Phase 5 回滚。

## Phase 4: Report

**目标:** 生成 HTML 报告 + 回填 CR。

15. **生成 `report/report.html`** — 基于 artifacts 真实数据,**不准杜撰数字**。
16. **填 `report/summary.md`** — 一页纸总结。
17. **回填 `cr/<id>-filled.md`** — AI 起草,owner review + 签字。
18. **提交到 CR 系统** — owner 操作,AI 不准代提交。
19. **本地 commit + push + tag** — Conventional Commits,scope 必填。

## Phase 5: Rollback (按需)

**触发条件:** verify 失败 / CR 拒绝 / 业务报告问题 / 监控告警。

20. **写 `scripts/rollback-<region>.sh`** — 默认 dry-run 模式,加 `--execute` 才真跑。
21. **dry-run 验证脚本** — 让 owner 看过反向操作列表。
22. **`rollback-<region>.sh --execute`** — owner 操作。
23. **新建 `caep-infra-vX.Y.Z-rollback/` 目录** — 记录回滚动作,绝不覆盖原 release。
24. **通知所有相关方** — 业务方、CR 审批人、监控团队。

## Phase 6: Close

25. **CR 关闭** — 等 CR 系统同步"已关闭"状态。
26. **7 天后 retrospective** — 在新 release 的 README 引用这个 release 的踩坑实录。
27. **更新 `architecture-overview.md`** — 反映新的资源清单。

## 强制约束(任何 phase 都不准违反)

🚫 不删 release 目录
🚫 不把 secret value 写进 commit
🚫 不让 AI 代提交 CR
🚫 不杜撰数字
🚫 不在跳板机外的环境跑 gcloud(本地 mac 不行)

## 反模式

❌ "我直接手动跑 gcloud,不用脚本" — 失去 audit trail
❌ "preflight 太慢,跳过" — 100% 会在 setup 阶段踩同样的坑
❌ "rollback 不用写,反正不会出问题" — 出问题就晚了
❌ "CR 我先代签字,后补" — 流程存在的意义就是审计
