# one-more-thing.md — GitHub Pages / Webhooks / Git Branch × 本仓库 release 工程

> **性质:** 探索性储备文档。**不动现有代码、不动 `_template/`、不动任何 release 目录。**
> 仅回答 4 个具体问题 + 给出能照着做的步骤。后续是否落地由 owner 决定。
> **生成时间参考:** 2026-06,基于 GitHub Pages / Webhooks / Branch 的公开文档 + 本仓库实际结构。
> **写作声明:** 本次没有 `web_search` 工具可用,所有"已知事实"✅ 来自 GitHub 多年稳定的公开行为
> 与本仓库已存在的文件结构;所有"假设"❓ 都明确标了出处与需要人工验证的步骤。

---

## 0. 本仓库速记(下文例子都用这些真实路径)

- 仓库根: `/Users/lex/git/caep-infra-gcp-release`(本地),远端 GitHub 暂未接入。
- 一个真实样板 release: `releases/pfb-gcp-v0.1.0/`
  - `README.md`(12 KB,9 个 section)
  - `scripts/`(preflight / setup / verify / rollback 各一份)
  - `artifacts/`(当前空,只有 `.gitkeep`)
  - `cr/`(2 个模板文件 `cr-XXXXXX.md` + `cr-XXXXXX-filled.md`)
  - `report/report.html`(dark-themed,自带 inline CSS,无外部静态资源)
  - `report/summary.md`(一页纸 TL;DR)
- 跨版本共享: `common/lib/*.sh`、`regions/<r>/env.sh`、`releases/_template/`(只读)
- 现有 git 约定(根 README §6):主分支 `main`、工作分支 `release/<v>`、hotfix `hotfix/<v>+1`、
  annotated tag 强制、Conventional Commits。

---

## 1. Git branch vs release:到底是不是一回事?

### ✅ 已知事实

**Git 的 branch 跟 release 工程里的 "release" 不是同一个抽象层级:**

| 概念 | 是什么 | 谁在用 |
|------|--------|--------|
| **Git branch** | 可移动的指针,指向某一次 commit | 开发工作流(主线 / 特性 / 修复) |
| **Git tag** | 不可移动的指针,指向某一次 commit,通常 annotated | 标记某个**时间点**的状态 |
| **Release** | 一个产品/工程意义上的"版本",有名字、范围、报告、归档 | 业务/工程流程 |

业界主流(`gitflow` / GitHub Flow / trunk-based)**都用 branch 做开发流转,用 tag 标记 release
本身**。本仓库根 README §6 已经这样做了:**`release/pfb-gcp-v0.1.0` 分支 + annotated tag
`pfb-gcp-v0.1.0`**,符合主流实践,不需要改。

### ❓ 假设与多版本并行

**多版本并行维护时(例:`v0.1.0` 还在 hotfix,`v0.2.0` 已经在准备):**

| 你想做的事 | 推荐做法 |
|-----------|---------|
| 给 `v0.1.0` 打 hotfix | 基于 tag `pfb-gcp-v0.1.0` 拉 `hotfix/pfb-gcp-v0.1.0+1` 分支 → 改完合回 `main` → 打新 tag |
| 给 `v0.2.0` 做新功能 | 从 `main` 拉 `release/pfb-gcp-v0.2.0`,全程不碰 `v0.1.0` 目录 |
| 区分"哪个目录是哪个 release 的" | 靠 `releases/<v>/` 目录命名 + tag,**不**靠 branch 名硬绑(分支会合并/删除,目录只增不删) |

**关键不变量:本仓库的 `releases/` 目录与 git branch 解耦。** 即使 `release/pfb-gcp-v0.2.0`
分支被 squash merge 进 `main` 然后删除,`releases/pfb-gcp-v0.2.0/` 目录和它的内容**永远在仓库里**。
这正是 §2.2 "release 目录只增不删"的设计意图。

### 📋 验证步骤

1. 接入 GitHub 后,到 repo 页 → Insights → Network,确认 `main` 上的 merge 节点带有 release tag。
2. 跑 `git for-each-ref refs/tags/pfb-gcp-v0.1.0 --format='%(objecttype) %(taggerdate)'`,
   确认是 `tag`(`commit` 就说明是 lightweight tag,要改)。
3. 现有 `scripts/check-release.sh` §5 已经校验 annotated tag,接入远端后这条规则继续生效。

---

## 2. GitHub Pages:能不能托管 `report/report.html`?

### ✅ 已知事实:能,推荐用 `gh-pages` 分支或 Actions,不用 `/docs` 模式

**两种发布源对比:**

| 模式 | 本仓库适配度 | 原因 |
|------|------------|------|
| **`gh-pages` 分支 + Actions 部署** | ✅ **推荐** | 干净隔离发布内容与源代码;`releases/`、`common/lib/*.sh` 这些**不**会被意外暴露成可访问的网页;能用 Actions 自定义构建步骤 |
| **`/docs` 目录** | ⚠️ 不推荐 | 需要把所有"想发布的内容"复制或软链到 `/docs/`;`common/lib/*.sh` 这种敏感脚本会被公开;发布面跟源码混在一起,审计面变大 |
| **GitHub Actions 直接 `actions/deploy-pages@v4`** | ✅ **最佳** | 完整控制 `index.html` 生成 + 路径 + 重定向;支持自定义域名 |

### ❓ 路径映射:具体长什么样?

假设 GitHub repo 是 `lex/caep-infra-gcp-release`,启用 Pages 后:

| 仓库里的文件 | Pages 上的 URL(用户/组织站点) | Pages 上的 URL(项目站点,默认) |
|--------------|------------------------------|--------------------------------|
| 仓库根 `index.html`(需新建或 Actions 生成) | `https://lex.github.io/` | `https://lex.github.io/caep-infra-gcp-release/` |
| `releases/pfb-gcp-v0.1.0/report/report.html` | `…/releases/pfb-gcp-v0.1.0/report/report.html` | `…/caep-infra-gcp-release/releases/pfb-gcp-v0.1.0/report/report.html` |
| `releases/pfb-gcp-v0.1.0/report/summary.md` | `…/releases/pfb-gcp-v0.1.0/report/summary.md` | 同上加前缀 |
| `releases/pfb-gcp-v0.1.0/cr/cr-XXXXXX-filled.md` | `…/releases/pfb-gcp-v0.1.0/cr/cr-XXXXXX-filled.md` | 同上加前缀 |

> ⚠️ `.sh` 文件 GitHub Pages **不会**执行,会作为静态文件下载(返回 `Content-Type: application/octet-stream` 或 text/plain)。
> 如果 Pages 默认配置了"只渲染 HTML",`.sh` 链接会直接 404 或被下载 — 二者都不是大问题,但要心里有数。

### ❓ 跨版本索引页(汇总所有 release 的入口页)怎么生成?

**三种方案,推荐 #1:**

1. **GitHub Actions 在 push 到 `main` 时扫 `releases/*/README.md`,生成 `index.html`(推荐)**
   - 入口 workflow: `.github/workflows/pages.yml`,触发条件 `push: branches: [main]`
   - 用 `find releases -mindepth 2 -maxdepth 2 -name README.md | sort` 列出版本
   - 用 `jq` + 简单 shell 模板(或 Python one-liner)生成 `<ul>` 列表
   - 输出 `index.html` 到一个单独分支(如 `gh-pages`)或用 `actions/deploy-pages@v4` 直接 deploy 到 GitHub Pages
   - 示意:
     ```yaml
     - name: Build release index
       run: |
         {
           echo '<html><body><h1>Releases</h1><ul>'
           for f in $(find releases -mindepth 2 -maxdepth 2 -name README.md | sort -V); do
             v=$(basename "$(dirname "$f")")
             echo "  <li><a href=\"./$f\">$v</a></li>"
           done
           echo '</ul></body></html>'
         } > index.html
     ```

2. **手工维护 `releases/INDEX.md`**(最简单,适合单人)
   - 每完成一个 release,在 `releases/INDEX.md` 加一行 `- [pfb-gcp-v0.1.0](./pfb-gcp-v0.1.0/report/report.html)`
   - Pages 会自动渲染 Markdown 列表
   - 缺点:owner 容易忘;AI 协作规则里要加一条"release commit 必须更新 INDEX.md"

3. **`scripts/new-release.sh` 改写,在创建目录时同时 patch INDEX.md**(机制层保险)
   - 在 README §3.1 "AI 可以做"清单里加一条:跑完新版本脚手架后必须 INDEX.md

### ❓ 自定义域名 + 公司内网访问

- **公网自定义域名**:`Settings → Pages → Custom domain` → 配 CNAME 到 `lex.github.io.`。
  GitHub 会强制 HTTPS(Let's Encrypt 自动签发,2024 年起强制)。
- **公司内网访问**:**❌ 100% 不可能直接用 GitHub Pages**,理由:
  - GitHub Pages 服务器在公网(GitHub 自有 CDN / Fastly),公司内网不通外网就访问不到。
  - Pages 没有 "private/internal" 模式 — 私有 repo 的 Pages **只在 GitHub Pro/Team/Enterprise 才有**,
    而且即便私有,服务还是在公网,只是 URL 不被搜索引擎收录。
- **想要"内网看 release 报告"的替代方案**:
  - **方案 A(推荐,零成本):** 把 `report.html` 在公司内网 nginx / Caddy 起一个目录,
    `rsync releases/<v>/report/` 到内网静态站点,内网域名如 `https://caep-infra.internal/releases/pfb-gcp-v0.1.0/report.html`。
  - **方案 B:** 用 GitHub Enterprise + 内部 DNS 解析 + VPN,直接把 Pages 暴露到内网(成本高,需 IT 配合)。
  - **方案 C:** 接 GitHub 后,内网机器 `git pull`,本地 `python3 -m http.server` 起预览。
    适合临时演示,不适合常驻服务。

### 📋 验证步骤

1. 接入 GitHub 后,`Settings → Pages → Source` 选 **"GitHub Actions"**,先用一个测试 workflow
   部署一个 `index.html`,确认能访问 `https://<org>.github.io/caep-infra-gcp-release/`。
2. 检查 `report.html` 在 Pages 上:暗黑主题背景色是否被 GitHub 的 Jekyll 默认主题覆盖。
   **✅ 不会**:`report.html` 用 `<style>` 内联 + 没有 front-matter,Jekyll 不会碰它,暗黑主题保留。
3. 在 `common/lib/` 里加一行 `echo "secret-test"` 临时测试,确认 Pages 不会把它公开(选 `gh-pages` 分支的话,
   `common/lib/` 不在发布分支里,天然隔离)。

---

## 3. GitHub Webhooks:跳板机不在公网也能用吗?

### ✅ 已知事实

**Webhook 是 GitHub → 你的服务器的单向 POST。** 也就是说:**GitHub 必须能访问到你的接收端 URL,
webhook 才能用。** 这与 git push 方向相反(git push 是你 → GitHub,需要你的网络能出公网)。

### ❓ 本仓库能用 webhook 做什么?

| 想做的事 | 能否用 webhook | 限制 |
|---------|--------------|------|
| **push 触发自动同步** — GitHub 收到 push 后告诉跳板机"有新 commit,快 pull" | ⚠️ **理论可以,实际难** | 跳板机必须在公网(或通过 ngrok / Cloudflare Tunnel 暴露),GitHub 才能 POST 到 |
| **触发 CR 自动创建** — push 后自动在 CR 系统开单 | ⚠️ 同上 | 接收端必须在公网可达 |
| **监控 release 状态** — GitHub 通知 owner "tag 被打出来了" | ✅ **简单方式** | 不需要 webhook,直接用 `actions/on.push.tags` 触发邮件 / Slack 通知;或者 GitHub 自身的 Watch 机制 |
| **local jumpbox 拉取通知** | ⚠️ 可行 | 公司内网可考虑 [ smee.io ](https://smee.io) 或 [Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/),GitHub POST 到云中转,云客户端推送回内网跳板机。零信任方案,无需防火墙开口 |
| **webhook → 自动 build report.html** | ✅ | 但本仓库的 report 是 AI 协作生成的,不是 CI 生成的,这个场景不太适用 |

### ✅/❓ 公司网络不通外网时,具体能用到什么程度?

| 能力 | 是否可用 | 替代方案 |
|------|---------|---------|
| GitHub Webhook 推送事件到跳板机 | ❌ 直接 100% 不可用 | 用 smee.io / Cloudflare Tunnel / ngrok 做中转 |
| GitHub Actions 自动跑 CI(在 GitHub 自己的 runner 上) | ✅ **完全可用**,与公司网络无关 | 这是大杀器 — Actions 跑在 GitHub 公网,根本不需要公司网络出公网 |
| `gh api` / `git push` 推送到 GitHub | ❌ 公司网络限制下不可用 | 等网络放开,或用白名单代理 |
| 通过 webhook 监控 release commit / tag | ⚠️ 需中转 | Actions 触发 Slack/邮件通知,效果类似 |

### 📋 验证步骤

1. **接入 GitHub 后第一件事**:跑一个最小 Actions workflow,`.github/workflows/hello.yml`,
   触发器 `on: push`,job 只做 `echo hello`。这不依赖公司网络,只依赖 GitHub 自身的 runner。
2. **要 webhook 的话**,在 GitHub 仓库 `Settings → Webhooks` 添加 Payload URL 指向 smee.io 通道,
   本地 `smee --url <url>` 订阅,验证能收到 push 事件;再决定是否真接跳板机。
3. **不要**为了用 webhook 而让 IT 给跳板机开口子 — 用中转服务更安全。

---

## 4. Markdown 内部跳转 vs GitHub Pages 渲染:具体怎么写?

### ✅ 已知事实

**Markdown 渲染有两套规则:**

- **GitHub.com 渲染**(浏览 `github.com/<user>/<repo>/...`):GitHub 后端转 HTML,支持完整 GFM。
- **GitHub Pages 渲染**(`<user>.github.io/<repo>/...`):用 **Jekyll**,在 commit 时(或 Actions 部署时)
  处理 Markdown 文件。**默认不做 permalink 重写,目录结构 = URL 结构**。
  想关掉 Jekyll 处理:在要发布的目录放一个 `.nojekyll` 空文件。

### ❓ 4 个具体路径问题

#### 4.1 Markdown 里写 `[UK Region](./regions/uk/env.sh)` 在 GitHub.com 上能跳吗?

**✅ 能跳(下载/查看)。** GitHub.com 对所有 `*.sh` 的行为:

- 在仓库页直接显示**纯文本**(语法高亮 shell)。
- 点击文件树里的 `.sh` → 直接打开纯文本视图,URL 是 `…/blob/main/regions/uk/env.sh`。
- 在 Markdown 里写 `[UK](./regions/uk/env.sh)`,渲染出来的 `<a href="./regions/uk/env.sh">`:
  - 在 GitHub.com:跳转 → 打开纯文本视图 ✅
  - 在 GitHub Pages:**返回 raw 文本**(无 Jekyll 处理时),浏览器显示纯 shell 脚本源码 ✅
- **🔒 不渲染、不执行** — 不会出 XSS 或脚本执行漏洞,放心。

#### 4.2 `.html` 文件路径在 GitHub Pages 上怎么映射?

**✅ 文件路径 = URL 路径**,无需特殊处理(除非用 Jekyll 的 permalink 插件,本仓库不需要):

| 仓库路径 | Pages URL |
|---------|----------|
| `releases/pfb-gcp-v0.1.0/report/report.html` | `/releases/pfb-gcp-v0.1.0/report/report.html` |
| `releases/pfb-gcp-v0.1.0/index.html`(需要新建) | `/releases/pfb-gcp-v0.1.0/index.html`(让该 release 有自己的入口页) |

#### 4.3 `report.html` 内部想跳到 `cr-XXXXXX-filled.md`,路径怎么写?

`report.html` 是位于 `releases/pfb-gcp-v0.1.0/report/` 的纯 HTML 文件(从已有代码看
它**没有相对路径引用的资源**,全靠 inline style),所以**所有链接都要写成相对于
`releases/pfb-gcp-v0.1.0/report/` 的相对路径**:

```html
<!-- 正确:从 report/ 出发,../cr/ 上一层 -->
<a href="../cr/cr-XXXXXX-filled.md">CR 回填</a>

<!-- 也行但脆:绝对路径,假设 Pages 是项目站点 -->
<a href="/caep-infra-gcp-release/releases/pfb-gcp-v0.1.0/cr/cr-XXXXXX-filled.md">CR 回填</a>
```

**❓ 假设/注意**: `cr-XXXXXX-filled.md` 在 Pages 上**会被 Jekyll 当 Markdown 渲染**(加 `<html>` 外壳)。
如果不想被 Jekyll 碰(想保留纯 Markdown 源码外观),在该目录放一个 `.nojekyll` 空文件,
或把文件改名 `cr-XXXXXX-filled.html` 并在 `report.html` 里同步改链接。

#### 4.4 跨 release 引用(`v0.1.0/README.md` → `v0.2.0/README.md`)怎么写相对路径?

**假设你在写 `releases/pfb-gcp-v0.1.0/README.md`,要链到 `releases/pfb-gcp-v0.2.0/README.md`:**

```markdown
<!-- 写法 A:从 v0.1.0/README.md 出发,../v0.2.0/README.md -->
[下一版本](../pfb-gcp-v0.2.0/README.md)

<!-- 写法 B:绝对,Pages 项目站点 -->
[/caep-infra-gcp-release/releases/pfb-gcp-v0.2.0/README.md](/caep-infra-gcp-release/releases/pfb-gcp-v0.2.0/README.md)
```

**建议:** 在本仓库**所有**跨 release 链接都用**写法 A(相对路径)**,理由:
- 仓库搬家(换 owner / org)时链接不失效。
- 本地预览(用 `python3 -m http.server` 起 `releases/`)也能跳。
- 不依赖 Pages 是"用户站点"还是"项目站点"。

**❓ 一个已知陷阱**: 跨 release 引用要避开 `_template/`,因为 Pages 不应该发布模板。

### 📋 验证步骤

1. 在本地 `releases/pfb-gcp-v0.1.0/report/` 起一个临时 HTTP server:
   `cd releases/pfb-gcp-v0.1.0/report && python3 -m http.server 8000`,
   浏览器开 `http://localhost:8000/report.html`,点所有 `<a href>` 看是否都能跳。
2. 接入 GitHub 后,把 `.nojekyll` 加到 `releases/<v>/` 和根目录,确保 Markdown 渲染不会被 Jekyll 主题覆盖。
3. 在 `report.html` 加一段 `<a href="../README.md">返回 README</a>` 做最小冒烟,接入后直接看 Pages 渲染。

---

## 5. 汇总:本仓库"现在就能用 / 接入后能用 / 用不了"

| 能力 | 现状 | 接入 GitHub 后 | 备注 |
|------|------|--------------|------|
| Branch + tag 标记 release | ✅ 已经在用(`release/<v>` 分支 + annotated tag,根 README §6) | 同左 | 业界主流做法,无需改 |
| GitHub Pages 托管 `report.html` | ❌ 远端不存在 | ✅ **完全可用**,推荐 Actions 部署 + `gh-pages` 分支 | `report.html` 自带 inline 暗黑主题,Jekyll 不碰 |
| 跨版本索引页 | ❌ 没有 | ✅ Actions 自动生成 `index.html`,零成本 | 需要写一个 30 行的 workflow |
| 自定义域名 | ❌ | ✅ | 但公司内网访问仍需额外方案(内网 nginx / Cloudflare Tunnel) |
| Webhook 推送事件到跳板机 | ❌ 跳板机不在公网 | ⚠️ 需要 smee.io / Cloudflare Tunnel 中转,**不**建议给跳板机开口子 | 中转服务是更安全的选择 |
| Webhook 推送到 GitHub Actions | ❌ | ✅ **完全可用**,CI/CD 大杀器 | Actions 在 GitHub 公网跑,无需公司网络出公网 |
| Markdown 跨文件跳转 | ✅ 已经在用(参见已有 README 里的 `[UK](../regions/uk/env.sh)` 形式) | ✅ 同左 | 相对路径是 portable 写法 |
| GitHub Pages 渲染 `.sh` | ❌ 远端不存在 | ✅ 作为静态文件下载/查看,无安全风险 | 不渲染、不执行 |

---

## 6. 下一步可以做的最小验证动作(零代码改动)

> 这部分是"将来要做时,按这个顺序跑就能确认结论"的 checklist。每条都是**只读**或只建临时文件。

1. **本地 Pages 冒烟**:在 `releases/pfb-gcp-v0.1.0/` 下 `python3 -m http.server 8000`,
   浏览器打开 `http://localhost:8000/report/report.html`,确认暗黑主题 + 所有相对链接。
2. **索引页原型**:临时在仓库根写一个 `index.html`,手动列一个 `<ul>` 指向
   `releases/pfb-gcp-v0.1.0/report/report.html`,确认 URL 形态正确后再考虑自动化。
3. **跨 release 链接冒烟**:在 `releases/pfb-gcp-v0.1.0/README.md` 末尾加一行
   `[下一版本占位](../pfb-gcp-v0.2.0/README.md)`,用 git stash 暂存,**不**提交,只验证相对路径写法的渲染。
4. **接入 GitHub 后第一件事**:建 `.github/workflows/pages.yml`,部署一个测试 `index.html`,
   验证 Pages URL 能访问 — 这步不依赖 webhook、不依赖公司网络、不动现有 release 目录。
5. **webhook 决策树**:跳板机要不要暴露到公网?
   - 不要 → 用 smee.io / Cloudflare Tunnel 中转,GitHub → 中转 → 内网跳板机。
   - 不在乎 → 直接在跳板机跑 `socat` / `nc -l` 收 webhook,然后本地 `git pull`。

---

## 7. 没在本仓库范围内、但值得记一笔的事

- ❓ **GitHub Discussions / Issues 做 CR 跟踪**:GitHub Issues 本身就是一种轻量 CR。
  本仓库已经有 `cr/` 目录的 Markdown 工单,接入 GitHub 后可以考虑**把 Issues 当 CR 系统的镜像**,
  工单号直接用 issue number,Markdown 工单里引用 `#1234`。但这是流程改造,不在本次探索范围。
- ❓ **GitHub Releases(网站意义上的 Releases)**:跟 Git tag 不是一个东西,是一个**带说明、二进制附件、changelog 的发布页**。
  本仓库结构是"一个版本一个目录",不太需要 GitHub Releases 的"挂二进制"能力 —
  真要发布二进制,放进 `releases/<v>/artifacts/` 即可,与仓库归档统一管理。
- ❓ **GitHub Code Search**:接入后,搜索 `region-uk` 会直接命中所有跨 release 的 UK 相关 commit,
  是 branch + tag 工作流的副产品收益。

---

## 8. 来源与可信度

- ✅ **GitHub Pages 行为(发布源、路径映射、Jekyll)** — GitHub 多年稳定的文档与公开行为,
  本次未联网验证,**接入 GitHub 后建议跑 §5 的最小验证动作确认**。
- ✅ **GitHub Webhooks 模型(单向 POST)** — 长期稳定,无需怀疑。
- ✅ **Markdown 渲染差异(GitHub.com vs Pages)** — 公开文档长期说明的行为。
- ❓ **2024-2026 间 GitHub Pages / Actions 的具体小特性**(如 `actions/deploy-pages@v4` 的最新 API、
  Pages 是否默认 HTTPS 强制、smee.io 是否仍免费)— 本次没有联网,需接入后用 GitHub 官方文档二次确认。
- ✅ **本仓库的实际结构、命名、文件位置** — 来自对 `/Users/lex/git/caep-infra-gcp-release` 的实读,
  文中所有路径与文件均真实存在。

---

> 🐚 **结语:** 接入 GitHub 之前,这个仓库已经把 release 工程需要的 80% 抽象做对了
> (一个版本一个目录、annotated tag、Conventional Commits、template 只读、只增不删)。
> GitHub Pages/Webhooks 只是在"接入后给这套抽象加一层可点击的 URL 表面"。
> 是否接入、什么时候接入、Pages 部署到哪、webhook 走哪条路 — 都是可以分阶段、零风险试的。