# regions/

5 Region 配置总览。每个 Region 有独立的 `env.sh`(覆盖 `common/lib/lib-jump.sh` 的默认值)
和 `projects/<project-id>/` 子目录(每个 Project 一份 README + 资源台账)。

## Region 速查

| Region | 显示名 | 跳板机实例 | 默认 GCP Location | 主要 Project 数 |
|--------|--------|------------|------------------|----------------|
| [uk](./uk/) | United Kingdom | `caep-jump-uk-01` | `europe-west2` | _待 Lex 补_ |
| [hk](./hk/) | Hong Kong       | `caep-jump-hk-01` | `asia-east2`     | _待 Lex 补_ |
| [in](./in/) | India           | `caep-jump-in-01` | `asia-south1`    | _待 Lex 补_ |
| [cn](./cn/) | China Mainland  | `caep-jump-cn-01` | (不适用 / 特殊) | _待 Lex 补_ |
| [us](./us/) | United States   | `caep-jump-us-01` | `us-central1`    | _待 Lex 补_ |

> ⚠ **CN Region 注意:** GCP 在中国大陆没有原生 region(Google Cloud China 是 partner 模式),
> 本目录假设你有 partner 账号或 VPN 桥接方案,具体 `env.sh` 等接入时再填。

## 子目录约定

```
regions/<r>/
├── env.sh                          # 该 Region 的 env 变量(Project ID 列表、跳板机、默认 location)
├── jumpbox.sh                      # 一键连该 Region 跳板机的快捷脚本
├── projects/
│   ├── <project-id-1>/
│   │   ├── README.md               # Project 用途 + 资源清单
│   │   ├── gke/                    # GKE 集群
│   │   ├── networking/             # VPC / Subnet / Firewall
│   │   ├── iam/                    # SA / 角色绑定
│   │   └── storage/                # Bucket / GAR
│   └── <project-id-2>/
│       └── ...
```

## 跳板机矩阵

| Region | gcloud 命令 | 备注 |
|--------|-------------|------|
| uk | `gcloud compute ssh lex_admin@caep-jump-uk-01 --project=caep-shared-uk-jumpbox --zone=europe-west2-a` | |
| hk | `... caep-jump-hk-01 ... asia-east2-a` | |
| in | `... caep-jump-in-01 ... asia-south1-a` | |
| cn | _(partner 账号专用,见 `cn/env.sh`)_ | 特殊 |
| us | `... caep-jump-us-01 ... us-central1-a` | |

更详细的网络拓扑见 [`../docs/architecture-overview.md`](../docs/architecture-overview.md)。
