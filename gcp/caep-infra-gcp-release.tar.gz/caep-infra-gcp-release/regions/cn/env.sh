#!/opt/homebrew/bin/bash
# regions/cn/env.sh — China Mainland Region 配置 (占位)
# =============================================================
# ⚠ CN Region 在 GCP 是 partner 模式,不能用普通 gcloud 操作。
# 本文件是占位,等 Lex 接入 partner 账号后填入实际配置。
# =============================================================

export REGION="cn"
export REGION_DISPLAY_NAME="China Mainland"
export REGION_TIMEZONE="Asia/Shanghai"

# TODO(Lex): 等接入后填入 partner 账号对应的 Project
# export PROJECT_CORE="<partner-account>:<project-id>"
# export ALL_PROJECTS=("$PROJECT_CORE")

# CN 没有原生 GCP region,location 用 partner 提供的 endpoint
# export DEFAULT_BUCKET_LOCATION="<partner-endpoint>"

# CN 跳板机: 大概率是国内云厂商(阿里云/腾讯云),不走 GCP IAP
# export JUMPBOX_INSTANCE="<cn-jumpbox-instance>"
# export JUMPBOX_PROJECT="<cn-jumpbox-project>"
