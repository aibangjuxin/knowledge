#!/opt/homebrew/bin/bash
# regions/hk/env.sh — Hong Kong Region 配置
# =============================================================

export REGION="hk"
export REGION_DISPLAY_NAME="Hong Kong"
export REGION_TIMEZONE="Asia/Hong_Kong"

# TODO(Lex): 填入 HK Region 实际 Project ID
export PROJECT_CORE="caep-prod-hk-core"
export PROJECT_DATA="caep-prod-hk-data"

export ALL_PROJECTS=(
    "$PROJECT_CORE"
    "$PROJECT_DATA"
)

export DEFAULT_BUCKET_LOCATION="asia-east2"
export DEFAULT_GAR_LOCATION="asia-east2"
export DEFAULT_GKE_LOCATION="asia-east2"

export JUMPBOX_PROJECT="caep-shared-hk-jumpbox"
export JUMPBOX_ZONE="asia-east2-a"
export JUMPBOX_INSTANCE="caep-jump-hk-01"
export JUMPBOX_USER="lex_admin"

export REGION_COMPLIANCE_FRAMEWORK="PDPO"
