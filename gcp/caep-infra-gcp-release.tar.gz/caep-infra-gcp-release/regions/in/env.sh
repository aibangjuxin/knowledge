#!/opt/homebrew/bin/bash
# regions/in/env.sh — India Region 配置
# =============================================================

export REGION="in"
export REGION_DISPLAY_NAME="India"
export REGION_TIMEZONE="Asia/Kolkata"

# TODO(Lex): 填入 IN Region 实际 Project ID
export PROJECT_CORE="caep-prod-in-core"
export PROJECT_DATA="caep-prod-in-data"

export ALL_PROJECTS=(
    "$PROJECT_CORE"
    "$PROJECT_DATA"
)

export DEFAULT_BUCKET_LOCATION="asia-south1"
export DEFAULT_GAR_LOCATION="asia-south1"
export DEFAULT_GKE_LOCATION="asia-south1"

export JUMPBOX_PROJECT="caep-shared-in-jumpbox"
export JUMPBOX_ZONE="asia-south1-a"
export JUMPBOX_INSTANCE="caep-jump-in-01"
export JUMPBOX_USER="lex_admin"

export REGION_COMPLIANCE_FRAMEWORK="DPDP"
