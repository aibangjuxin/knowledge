#!/opt/homebrew/bin/bash
# regions/uk/env.sh — United Kingdom Region 配置
# =============================================================
# 加载: source "$(dirname ${BASH_SOURCE[0]})/env.sh"
# =============================================================

export REGION="uk"
export REGION_DISPLAY_NAME="United Kingdom"
export REGION_TIMEZONE="Europe/London"

# ---------- Project ID 列表 ----------
# TODO(Lex): 填入 UK Region 实际 Project ID
export PROJECT_CORE="caep-prod-uk-core"
export PROJECT_DATA="caep-prod-uk-data"
export PROJECT_NET="caep-prod-uk-net"
export PROJECT_LOG="caep-prod-uk-log"

export ALL_PROJECTS=(
    "$PROJECT_CORE"
    "$PROJECT_DATA"
    "$PROJECT_NET"
    "$PROJECT_LOG"
)

# ---------- 默认配置 ----------
export DEFAULT_BUCKET_LOCATION="europe-west2"
export DEFAULT_BUCKET_CLASS="STANDARD"
export DEFAULT_GAR_LOCATION="europe-west2"
export DEFAULT_GKE_LOCATION="europe-west2"

# ---------- 跳板机配置 ----------
export JUMPBOX_PROJECT="caep-shared-uk-jumpbox"
export JUMPBOX_ZONE="europe-west2-a"
export JUMPBOX_INSTANCE="caep-jump-uk-01"
export JUMPBOX_USER="lex_admin"

# ---------- 业务配置 ----------
# UK 是 GDPR 主战场,所有 bucket 默认开 uniform-bucket-level-access + retention policy
export REGION_COMPLIANCE_FRAMEWORK="GDPR"
export REGION_BUCKET_RETENTION_DAYS=30
