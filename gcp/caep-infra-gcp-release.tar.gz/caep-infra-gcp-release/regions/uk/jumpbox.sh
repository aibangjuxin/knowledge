#!/opt/homebrew/bin/bash
# =============================================================
# regions/uk/jumpbox.sh — 一键连 UK 跳板机
# =============================================================
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/env.sh"

exec gcloud compute ssh "${JUMPBOX_USER}@${JUMPBOX_INSTANCE}" \
    --project="${JUMPBOX_PROJECT}" \
    --zone="${JUMPBOX_ZONE}"
