# caep-prod-uk-core (样板)

> ⚠ **本 README 是样板,内容是示意。** 真实 Project 的 README 应在首次操作时由 AI 协助补全。

## 基本元信息

| 字段 | 值 |
|------|-----|
| Project ID | `caep-prod-uk-core` |
| Project Number | _(待填)_ |
| Region | `europe-west2` (London) |
| 合规框架 | GDPR |
| 业务用途 | UK Region 核心服务 (frontend / API / worker) |
| 拥有者 | _(待填)_ |
| 成本中心 | _(待填)_ |

## 资源清单

### GKE 集群
- `caep-uk-core-prod` — _(待填:节点数、版本、private/public)_

### Networking
- VPC: `caep-uk-core-vpc` — CIDR `10.0.0.0/16`
- Subnets: _(待填)_

### Storage
- Bucket: `caep-uk-core-artifacts` — region `europe-west2`,STANDARD
- Bucket: `caep-uk-core-logs` — region `europe-west2`,NEARLINE,30 天 retention

### IAM
- SA `caep-uk-core-runtime@...` — roles/run.invoker, roles/artifactregistry.reader

## 关联 release

| Release | 涉及此 Project 的脚本 | 验证结果 |
|---------|---------------------|---------|
| _(待填)_ | _(待填)_ | _(待填)_ |
