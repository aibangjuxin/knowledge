#!/opt/homebrew/bin/bash
# regions/us/env.sh — United States Region 配置
# =============================================================

export REGION="us"
export REGION_DISPLAY_NAME="United States"
export REGION_TIMEZONE="America/New_York"

# TODO(Lex): 填入 US Region 实际 Project ID
export PROJECT_CORE="caep-prod-us-core"
export PROJECT_DATA="caep-prod-us-data"
export PROJECT_NET="caep-prod-us-net"

export ALL_PROJECTS=(
    "$PROJECT_CORE"
    "$PROJECT_DATA"
    "$PROJECT_NET"
)

export DEFAULT_BUCKET_LOCATION="us-central1"
export DEFAULT_GAR_LOCATION="us-central1"
export DEFAULT_GKE_LOCATION="us-central1"

export JUMPBOX_PROJECT="caep-shared-us-jumpbox"
export JUMPBOX_ZONE="us-central1-a"
export JUMPBOX_INSTANCE="caep-jump-us-01"
export JUMPBOX_USER="lex_admin"

export REGION_COMPLIANCE_FRAMEWORK="CCPA"
