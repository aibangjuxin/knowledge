# releases/

所有历史 release 的归档。每个 release 是一个**独立目录**,只增不删。

## 命名规范

```
caep-infra-v<MAJOR>.<MINOR>.<PATCH>
```

例:`pfb-gcp-v0.1.0`、`caep-infra-v1.2.3`、`caep-infra-v1.2.3-rollback`(回滚版本)。
> 实际业务版本号 prefix 由 release owner 决定,本仓库的 `new-release.sh` 默认接受 `caep-infra-vX.Y.Z` 格式;
> 使用其他 prefix(如 `pfb-gcp-vX.Y.Z`)时需先改 `scripts/new-release.sh` 的正则。

## 强制结构

每个 release 目录**必须**有这 4 个子目录 + 1 个 README:

```
caep-infra-vX.Y.Z/
├── README.md         # ★ 本版本元信息 + 流程记录 (AI 主要维护的对象)
├── scripts/          # 本版本实际跑过的脚本 (preflight/setup/verify/rollback)
├── artifacts/        # 跑出来的真实备份 (gcloud describe json / terraform plan)
├── cr/               # Change Request 工单及回填内容
└── report/           # HTML 报告 + 一页纸 summary
```

## 创建流程

```bash
# 1) 跑新版本脚手架
./scripts/new-release.sh caep-infra-vX.Y.Z

# 2) 改 README.md 的"基本元信息"section

# 3) 写 scripts/ 下的脚本(从 _template/ 复制起步)

# 4) 跑 preflight + setup + verify

# 5) 把 artifacts/ 与 report/ 同步回本仓库

# 6) 提交 + 打 tag
git add releases/<新版本>/
git commit -m "release(<新版本>): ..."
git tag -a <新版本> -m "..."
```

## 与 `_template/` 的关系

`_template/README.md` 是**唯一**的 release README 模板。任何新 release 必须 `cp _template/ caep-infra-vX.Y.Z/`,
然后**只填内容,不改结构**。

🚫 **禁止改 _template/**:即使你这次 release 想加新 section,也**新建** `caep-infra-vX.Y.Z.README.local.md` 放在本版本目录,
绝不改模板。`_template/` 改了会让历史 release 的 README "看起来不一致"。
