# Release Template — caep-infra-vX.Y.Z

> 🚫 **本文件是模板,任何人/AI 不准修改。** 新版本必须 `cp _template/ caep-infra-vX.Y.Z/`,然后只填内容。

> 🤖 **AI 协作说明:** 当用户说"帮我完善这个 release 的 README"或"按这个模板写一份 v0.1.0",
> 请:
> 1. 严格按下面 8 个 section 的顺序填充
> 2. 不删任何 section,空内容填 `_(无)_`
> 3. 不存在的真实数据填 `_(待人工填写)_`,并在第 6 节"已知缺口"列出
> 4. **绝对不杜撰**:不存在的 Project ID、虚构的 quota、臆造的验证结果

---

## 0. 修订记录

| 版本 | 日期 | 作者 | 变更摘要 |
|------|------|------|---------|
| _vX.Y.Z_ | _YYYY-MM-DD_ | _Lex / AI 辅助_ | 初始 release |

---

## 1. 基本元信息(必填)

| 字段 | 值 |
|------|-----|
| Release 版本 | `caep-infra-vX.Y.Z` |
| 上一版本 | `_(待填,例:caep-infra-vX.Y.W)_` |
| Release 类型 | _(BREAKING / FEATURE / PATCH)_ |
| 涉及 Region | _(勾选) [ ] UK [ ] HK [ ] IN [ ] CN [ ] US_ |
| 涉及 Project | _(列出所有 Project ID,一行一个)_ |
| 计划开始时间 | _YYYY-MM-DD HH:MM (时区)_ |
| 实际开始时间 | _YYYY-MM-DD HH:MM_ |
| 实际完成时间 | _YYYY-MM-DD HH:MM_ |
| 计划 CR 工单号 | _CR-XXXXXX_ |
| 实际 CR 工单号 | _CR-XXXXXX_ |
| CR 创建人 | _Lex_ |
| 实施负责人 | _Lex_ |
| 验证人 | _Lex / (待指定)_ |
| 紧急回滚联系人 | _Lex 手机_ |

---

## 2. 变更范围(必填)

### 2.1 资源变更清单

按 Region + Project 分组,逐条列出本次操作了哪些资源。

**例:**

#### UK — `caep-prod-uk-core`
- [ ] 创建 GCS bucket `caep-uk-core-artifacts` (location=europe-west2, class=STANDARD)
- [ ] 创建 GAR repo `caep-uk-core-images` (format=DOCKER)
- [ ] 创建 SA `caep-uk-core-runtime@...` 并绑 role `roles/run.invoker`
- [ ] 创建 Secret `caep-uk-core-db-password` (value 来自...)
- [ ] DNS: 给 `api.example.com` 添加 A 记录指向 GLB IP

#### HK — `caep-prod-hk-core`
- [ ] _(待填)_

#### IN / CN / US
- [ ] _(待填)_

### 2.2 依赖与前置

- 上一 release `caep-infra-vX.Y.W` 已完成
- 跳板机上的 `common/lib/` 已与本仓库同步
- 涉及的 SA / Service Account 配额充足
- 涉及的 Project 已在该 Region 跳板机有 access

### 2.3 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| 例:GAR repo 名字冲突 | 低 | 中 | preflight 阶段调 `_gar_repo_exists` 检查 |
| 例:跨 Region DNS 传播慢 | 中 | 低 | 提前 24h 降 TTL 至 300 |

---

## 3. 实施时间线(按需填写)

| 步骤 | 开始 | 结束 | 操作人 | 状态 |
|------|------|------|--------|------|
| preflight | | | | ⬜ 未开始 |
| setup-uk | | | | ⬜ 未开始 |
| verify-uk | | | | ⬜ 未开始 |
| setup-hk | | | | ⬜ 未开始 |
| verify-hk | | | | ⬜ 未开始 |
| ... | | | | ⬜ 未开始 |
| 收集 artifacts | | | | ⬜ 未开始 |
| 生成 report.html | | | | ⬜ 未开始 |
| 回填 CR | | | | ⬜ 未开始 |

---

## 4. 脚本与执行(必填,逐个 Region)

### 4.1 UK

**scripts/preflight-uk.sh**
- 目的: 在跑 setup 前检查所有前置(SA 存在 / 配额够 / 上一个 release 已 commit)
- 退出码: 0 = 全部通过,非 0 = 有阻断项
- 输出: `artifacts/uk-preflight-YYYYMMDD-HHMM.log`

**scripts/setup-uk.sh**
- 目的: 实际创建 / 更新 / 删除资源
- 复用 lib: `lib-bucket.sh`, `lib-gar.sh`, `lib-iam.sh`, `lib-secret.sh`
- 幂等性: ✅ (每个 create 操作都先 _xxx_exists 检查)
- 输出: `artifacts/uk-setup-YYYYMMDD-HHMM.log` + `artifacts/uk-*.json` (资源描述快照)

**scripts/verify-uk.sh**
- 目的: 跑完后逐项验证(资源存在 / 配置正确 / RBAC 通)
- 复用 lib: 同上
- 退出码: 0 = 全部通过,非 0 = 有失败项
- 输出: `artifacts/uk-verify-YYYYMMDD-HHMM.log`

**scripts/rollback-uk.sh** (可选但强烈建议)
- 目的: 紧急回滚 — 反向操作 setup 中的创建/更新
- 复用 lib: 同上
- 触发条件: verify 失败 / CR 拒绝 / 业务侧报告问题

### 4.2 HK
_(同上结构)_

### 4.3 IN / CN / US
_(同上结构)_

---

## 5. 验证结果(必填)

每个 Region 跑完 verify 后,把结果摘要贴这里。

### 5.1 UK 验证

| 资源 | 期望 | 实际 | 通过? |
|------|------|------|------|
| bucket `caep-uk-core-artifacts` | 存在 + location=europe-west2 | _(待填)_ | ⬜ |
| GAR repo `caep-uk-core-images` | 存在 + format=DOCKER | _(待填)_ | ⬜ |
| SA `caep-uk-core-runtime` | 存在 + 已绑 role | _(待填)_ | ⬜ |
| Secret `caep-uk-core-db-password` | 存在 + 1+ 版本 | _(待填)_ | ⬜ |
| DNS A 记录 `api.example.com` | 指向预期 IP | _(待填)_ | ⬜ |

### 5.2 HK 验证
_(同上)_

### 5.3 IN / CN / US 验证
_(同上)_

---

## 6. 已知缺口(必填,这是 AI 必填的关键 section)

> 🤖 **AI 必填:** 任何 `_(待人工填写)_` 的地方,都必须在这里列出来。

- [ ] _(例)HK Region 的 PROJECT_DATA 实际 ID 还没确认,占位为 caep-prod-hk-data_
- [ ] _(例)IN Region 跳板机跳板机 zone 信息没在 regions/in/env.sh 填入_
- [ ] _(例)report.html 还没生成,scripts 跑通后跑 ./scripts/build-report.sh_

---

## 7. 踩坑实录(必填 — 可复现的报错原文 + 原因 + 修法)

> 这部分是 release 最重要的经验沉淀。每次踩坑都按下面三段记录:
> **报错原文 → 原因 → 修法**。缺一段不算"已记录"。

### 7.1 _(举例)Backend service add-backend 失败_

**报错原文:**
```
ERROR: (gcloud.compute.backend-services.add-backend) Invalid value for field
'resource.backends[0]': ''. A backend with balancing mode UTILIZATION requires a
...
```

**原因:** 在 EXTERNAL_MANAGED + PSC NEG 场景下,`gcloud compute backend-services
add-backend` 三个 balancing mode (UTILIZATION / RATE / CONNECTION) 全部被拒,
已知的 gcloud CLI 限制(2026-06 验证)。

**修法:** 用 `gcloud compute backend-services import` + YAML,直接写
`backends: [{group: NEG-url, balancingMode: UTILIZATION, capacityScaler: 1.0}]`,
YAML 里 `loadBalancingScheme` 必须是 `EXTERNAL_MANAGED`(**下划线**,不能空格)。

(更多踩坑从此处继续追加)

### 7.2 _(举例)Cert "this root certificate is not trusted"_

**报错原文:** _浏览器 / curl 报错原文_

**原因:** _真实原因,不是猜的_

**修法:** _真实修法,验证过_

---

## 8. CR 回填引用(必填)

| CR 工单号 | 工单原文 | 回填内容 | 状态 |
|----------|---------|---------|------|
| CR-XXXXXX | [cr-XXXXXX.md](./cr/cr-XXXXXX.md) | [cr-XXXXXX-filled.md](./cr/cr-XXXXXX-filled.md) | 待批准 |

> 🚫 AI 不准在此表里写"已批准"。状态只能从 CR 系统同步过来,或由 release owner 人工填入。

---

## 9. 附件与索引

- `scripts/` — 本次跑过的所有脚本
- `artifacts/` — gcloud describe 快照、terraform plan、verify log
- `cr/` — CR 工单及回填
- `report/report.html` — 自动化 HTML 报告
- `report/summary.md` — 一页纸总结
