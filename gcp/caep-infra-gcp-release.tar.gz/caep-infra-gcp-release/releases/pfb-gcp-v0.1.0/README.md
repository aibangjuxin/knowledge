# Release pfb-gcp-v0.1.0

> **本版本是样板,展示 release README 应该长什么样。** 真实内容由 release owner + AI 协作填入。
> 模板见 [`../_template/README.md`](../_template/README.md),本文件**不**改模板结构。

---

## 0. 修订记录

| 版本 | 日期 | 作者 | 变更摘要 |
|------|------|------|---------|
| v0.1.0 | _(待填)_ | Lex (AI 辅助起草) | 初始 release — 仓库脚手架 + UK Region 一个 Project 的端到端跑通示范 |

---

## 1. 基本元信息

| 字段 | 值 |
|------|-----|
| Release 版本 | `pfb-gcp-v0.1.0` |
| 上一版本 | _(无,首版)_ |
| Release 类型 | PATCH (脚手架首版) |
| 涉及 Region | [x] UK [ ] HK [ ] IN [ ] CN [ ] US |
| 涉及 Project | `caep-prod-uk-core` |
| 计划开始时间 | _(待填)_ |
| 实际开始时间 | _(待填)_ |
| 实际完成时间 | _(待填)_ |
| 计划 CR 工单号 | CR-XXXXXX |
| 实际 CR 工单号 | _(待填)_ |
| CR 创建人 | Lex |
| 实施负责人 | Lex |
| 验证人 | Lex |
| 紧急回滚联系人 | Lex 手机 |

---

## 2. 变更范围

### 2.1 资源变更清单

#### UK — `caep-prod-uk-core`
- [ ] 创建 GCS bucket `caep-uk-core-artifacts` (location=europe-west2, class=STANDARD, 30 天 retention)
- [ ] 创建 GAR repo `caep-uk-core-images` (format=DOCKER, location=europe-west2)
- [ ] 创建 SA `caep-uk-core-runtime` 并绑 role `roles/run.invoker` + `roles/artifactregistry.reader`
- [ ] 创建 Secret `caep-uk-core-db-password` (value 来自 1Password 临时导出,**不入仓**)
- [ ] DNS: 给 `api.example.com` 添加 A 记录指向待定的 GLB IP

#### HK / IN / CN / US
- [ ] _(无,本版本只跑 UK)_

### 2.2 依赖与前置

- 上一 release: _(无,首版)_
- 跳板机上的 `common/lib/` 必须与本仓库 HEAD 一致 — 跑 `scripts/check-release.sh` 验证
- `lex_admin` 账号在 UK 跳板机有 sudo + gcloud admin
- `caep-prod-uk-core` project 的 Owner role 已经给到 `lex_admin@`

### 2.3 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| bucket 名全局冲突 | 极低 | 中 | preflight 阶段 `_bucket_exists` |
| Secret 创建后无法 verify 真实内容 | 中 | 低 | 部署侧单独 verify 业务连通性,infra 侧只验"版本数 >= 1" |
| DNS 记录 TTL 过长导致回滚慢 | 中 | 中 | preflight 阶段把 TTL 降到 300 |

---

## 3. 实施时间线

| 步骤 | 开始 | 结束 | 操作人 | 状态 |
|------|------|------|--------|------|
| preflight | | | | ⬜ 未开始 |
| setup-uk | | | | ⬜ 未开始 |
| verify-uk | | | | ⬜ 未开始 |
| 收集 artifacts | | | | ⬜ 未开始 |
| 生成 report.html | | | | ⬜ 未开始 |
| 回填 CR | | | | ⬜ 未开始 |

---

## 4. 脚本与执行

### 4.1 UK

**`scripts/preflight-uk.sh`**
- 目的: 检查 common/lib 同步、gcloud auth、project access、quota
- 退出码: 0 = 通过, 1 = 阻断
- 输出: `artifacts/uk-preflight-YYYYMMDD-HHMM.log`

**`scripts/setup-uk.sh`**
- 目的: 创建 bucket / GAR / SA / Secret / DNS
- 复用 lib: `lib-bucket.sh`, `lib-gar.sh`, `lib-iam.sh`, `lib-secret.sh`, `lib-dns.sh`
- 幂等性: ✅
- 输出: `artifacts/uk-setup-*.log` + `artifacts/uk-*.json` 资源描述

**`scripts/verify-uk.sh`**
- 目的: 跑完逐项验证
- 复用 lib: 同 setup
- 输出: `artifacts/uk-verify-*.log`

**`scripts/rollback-uk.sh`** (强烈建议)
- 目的: 反向操作,删除 setup 创建的所有资源
- 触发: verify 失败 / CR 拒绝 / 业务报告问题

### 4.2 HK / IN / CN / US
_(本版本无)_

---

## 5. 验证结果

### 5.1 UK 验证

| 资源 | 期望 | 实际 | 通过? |
|------|------|------|------|
| bucket `caep-uk-core-artifacts` | 存在 + location=europe-west2 | _(待填)_ | ⬜ |
| GAR repo `caep-uk-core-images` | 存在 + format=DOCKER | _(待填)_ | ⬜ |
| SA `caep-uk-core-runtime` | 存在 + 已绑 role | _(待填)_ | ⬜ |
| Secret `caep-uk-core-db-password` | 存在 + 1+ 版本 | _(待填)_ | ⬜ |
| DNS A 记录 `api.example.com` | 指向预期 IP | _(待填)_ | ⬜ |

---

## 6. 已知缺口

> 🤖 AI 必填。release owner 必须 review 这部分。

- [ ] `caep-prod-uk-core` 真实 Project ID 是否 = `caep-prod-uk-core` 待与公司 GCP 组织 admin 确认
- [ ] UK 跳板机实例名 `caep-jump-uk-01` 暂为占位,实际可能叫 `caep-jump-uk-prod-01`
- [ ] 跳板机 zone `europe-west2-a` 是否准确(可能用 `b` 或 `c`)
- [ ] `regions/uk/projects/caep-prod-uk-core/` 下的资源清单还是骨架,需要首次跑 setup 后回填
- [ ] `report/report.html` 与 `report/summary.md` 等 setup 跑通后由 `./scripts/build-report.sh` 生成

---

## 7. 踩坑实录

> 🚧 暂未跑实际命令,以下条目为脚手架阶段预判的高概率坑点,**不是已发生**。
> 实际跑通后请用真实三段式(报错原文 → 原因 → 修法)覆盖。

### 7.1 预判:`_bucket_create` 在 UK 区域报"location invalid"

**报错原文:** _(待首次跑时填入)_

**原因预判:** UK 的 `DEFAULT_BUCKET_LOCATION=europe-west2` 可能因为 region 限制需要换成
`europe-west4` (Netherlands) 或 `europe-west2` 实际不被公司账号白名单允许。

**修法预判:** 用 `gcloud storage buckets describe` 列允许 region,改 `regions/uk/env.sh`。

### 7.2 预判:Secret 1Password 导出格式问题

**报错原文:** _(待首次跑时填入)_

**原因预判:** 1Password CLI 导出的 secret value 末尾可能有 `\n` 或 BOM,导致 Secret Manager
add version 失败。

**修法预判:** 在 `_secret_put` 之前 `echo -n` 去掉 newline。

(更多踩坑待实际跑通后追加)

---

## 8. CR 回填引用

| CR 工单号 | 工单原文 | 回填内容 | 状态 |
|----------|---------|---------|------|
| CR-XXXXXX | [cr-XXXXXX.md](./cr/cr-XXXXXX.md) | [cr-XXXXXX-filled.md](./cr/cr-XXXXXX-filled.md) | 待批准 |

---

## 9. 附件与索引

- [`scripts/`](./scripts/) — 本次跑过的所有脚本
- [`artifacts/`](./artifacts/) — gcloud describe 快照
- [`cr/`](./cr/) — CR 工单及回填
- [`report/`](./report/) — HTML 报告 + summary
