# CR-XXXXXX — pfb-gcp-v0.1.0 回填内容

> ⚠ 本文件由 AI 起草,release owner **必须 review + 签字** 后才能提交到 CR 系统。
> 🚫 AI 不准在本文件里写"已批准" — 状态从 CR 系统同步。

## 1. 实际执行结果

| 步骤 | 计划开始 | 实际开始 | 实际结束 | 状态 |
|------|---------|---------|---------|------|
| preflight-uk | | | | ⬜ |
| setup-uk | | | | ⬜ |
| verify-uk | | | | ⬜ |

## 2. 实际变更清单

### UK — `caep-prod-uk-core`
- GCS bucket `caep-uk-core-artifacts`: _(待填,实际 location/class/retention)_
- GAR repo `caep-uk-core-images`: _(待填,实际 format)_
- SA `caep-uk-core-runtime`: _(待填,实际绑定的 role)_
- Secret `caep-uk-core-db-password`: _(待填,版本号)_

## 3. 验证摘要

(直接引用本 release `README.md` 第 5 节"验证结果"的内容)

## 4. 已知问题

(直接引用本 release `README.md` 第 6 节"已知缺口"的内容)

## 5. 后续行动

- [ ] 监控 bucket / GAR / SA 的前 24h 异常
- [ ] 通知业务方变更完成
- [ ] 7 天后做 release retrospective

## 6. 附件

- `artifacts/uk-bucket-artifacts.json`
- `artifacts/uk-gar-images.json`
- `artifacts/uk-sa-runtime.json`
- `artifacts/uk-verify-*.log`
- `report/report.html`
