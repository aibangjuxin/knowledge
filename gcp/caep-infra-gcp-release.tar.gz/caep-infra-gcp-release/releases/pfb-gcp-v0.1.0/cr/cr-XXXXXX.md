# CR-XXXXXX — (CR 标题,例:pfb-gcp-v0.1.0 rollout to UK region)

> 本节是 CR 工单原文,跑完后在 `cr-XXXXXX-filled.md` 里写回填内容。

## 变更类型
- [ ] 新功能
- [ ] Bug 修复
- [x] 基础设施变更

## 业务影响
(由 CR 创建人填写)

## 计划变更窗口
- 开始: YYYY-MM-DD HH:MM (Europe/London)
- 结束: YYYY-MM-DD HH:MM

## 涉及资源
(由 CR 创建人填写 — 可直接复制本 release 的 `README.md` 第 2 节)

## 风险等级
(由 CR 创建人填写)

## 审批人
(由 CR 创建人填写)
