#!/opt/homebrew/bin/bash
# scripts/preflight-uk.sh — UK Region preflight
# 退出码 0 = 通过, 1 = 阻断
#
# 改版 (Phase 2 enhancement): 用 lib-gcp.sh 替代 2 处硬编码
# gcloud auth list / gcloud projects describe, 用 lib-bucket/gar
# 做资源冲突预检。
# =============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../../.." && pwd)"

source "${ROOT_DIR}/common/lib/lib-log.sh"
source "${ROOT_DIR}/common/lib/lib-gcp.sh"
source "${ROOT_DIR}/common/lib/lib-bucket.sh"
source "${ROOT_DIR}/common/lib/lib-gar.sh"
source "${ROOT_DIR}/regions/uk/env.sh"

_log_section "UK Preflight — pfb-gcp-v0.1.0"

# ---------- 1. gcloud auth ----------
_gcp_require_auth

# ---------- 2. Project access ----------
_gcp_require_project_access "$PROJECT_CORE"

# ---------- 3. common/lib 同步检查 ----------
_log_info "TODO: 与跳板机上的 common/lib 做 diff (脚本 cr-sync.sh 后续提供)"

# ---------- 4. 资源冲突预检 ----------
if [[ "$(_bucket_exists "$PROJECT_CORE" "caep-uk-core-artifacts")" == "true" ]]; then
    _log_warn "bucket gs://caep-uk-core-artifacts 已存在,setup 将跳过创建"
fi

if [[ "$(_gar_repo_exists "$PROJECT_CORE" "$DEFAULT_GAR_LOCATION" "caep-uk-core-images")" == "true" ]]; then
    _log_warn "GAR repo caep-uk-core-images 已存在,setup 将跳过创建"
fi

_log_section "UK Preflight 完成"
_log_info "✅ 所有 preflight 项通过"
