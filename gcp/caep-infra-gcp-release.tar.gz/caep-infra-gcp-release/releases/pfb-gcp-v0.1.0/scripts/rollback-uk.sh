#!/opt/homebrew/bin/bash
# scripts/rollback-uk.sh — UK Region 紧急回滚
# 反向操作 setup-uk.sh 创建的所有资源
# ⚠ 默认 dry-run 模式,加 --execute 才真删
# =============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../../.." && pwd)"

source "${ROOT_DIR}/common/lib/lib-log.sh"
source "${ROOT_DIR}/common/lib/lib-bucket.sh"
source "${ROOT_DIR}/common/lib/lib-gar.sh"
source "${ROOT_DIR}/common/lib/lib-iam.sh"
source "${ROOT_DIR}/common/lib/lib-secret.sh"
source "${ROOT_DIR}/regions/uk/env.sh"

EXECUTE=false
for arg in "$@"; do
    case "$arg" in
        --execute) EXECUTE=true ;;
        --help|-h)
            echo "用法: $0 [--execute]"
            echo "  默认 dry-run 模式,只打印将执行的操作,不做任何修改"
            echo "  --execute  真正执行回滚(危险!)"
            exit 0
            ;;
    esac
done

_log_section "UK Rollback — pfb-gcp-v0.1.0"
if ! $EXECUTE; then
    _log_warn "DRY-RUN 模式,以下操作不会真执行。加 --execute 才真跑。"
fi

# 1. Secret (最先删,依赖最少)
_log_info "将删除 secret caep-uk-core-db-password"
$EXECUTE && _secret_rm "$PROJECT_CORE" "caep-uk-core-db-password"

# 2. SA + IAM
_log_info "将删除 SA caep-uk-core-runtime (会先 unbind role)"
$EXECUTE && gcloud iam service-accounts delete "caep-uk-core-runtime@${PROJECT_CORE}.iam.gserviceaccount.com" --project="$PROJECT_CORE" --quiet

# 3. GAR
_log_info "将删除 GAR repo caep-uk-core-images"
$EXECUTE && gcloud artifacts repositories delete "caep-uk-core-images" --project="$PROJECT_CORE" --location="$DEFAULT_GAR_LOCATION" --quiet

# 4. Bucket (最后删,会先清空)
_log_info "将删除 bucket caep-uk-core-artifacts (含所有对象)"
$EXECUTE && _bucket_rm "$PROJECT_CORE" "caep-uk-core-artifacts" --force-empty

if $EXECUTE; then
    _log_info "✅ UK 回滚完成"
else
    _log_info "DRY-RUN 完成,加 --execute 真正执行"
fi
