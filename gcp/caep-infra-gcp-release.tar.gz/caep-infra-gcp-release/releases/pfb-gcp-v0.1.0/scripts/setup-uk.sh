#!/opt/homebrew/bin/bash
# scripts/setup-uk.sh — UK Region 资源创建
# 幂等: 多次跑结果一致
#
# 改版 (Phase 2 enhancement): 用 lib-artifact.sh 替代 3 处硬编码
# gcloud describe。设 setup/verify 共享 lib-* 复用。
# =============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../../.." && pwd)"

source "${ROOT_DIR}/common/lib/lib-log.sh"
source "${ROOT_DIR}/common/lib/lib-bucket.sh"
source "${ROOT_DIR}/common/lib/lib-gar.sh"
source "${ROOT_DIR}/common/lib/lib-iam.sh"
source "${ROOT_DIR}/common/lib/lib-secret.sh"
source "${ROOT_DIR}/common/lib/lib-artifact.sh"
source "${ROOT_DIR}/regions/uk/env.sh"

ARTIFACT_DIR="${SCRIPT_DIR}/../artifacts"
mkdir -p "$ARTIFACT_DIR"

_log_section "UK Setup — pfb-gcp-v0.1.0"

# ---------- 1. Bucket ----------
_bucket_create "$PROJECT_CORE" "caep-uk-core-artifacts" "$DEFAULT_BUCKET_LOCATION" "$DEFAULT_BUCKET_CLASS"

# ---------- 2. GAR ----------
_gar_repo_create "$PROJECT_CORE" "$DEFAULT_GAR_LOCATION" "caep-uk-core-images" "DOCKER"

# ---------- 3. SA + IAM ----------
_iam_sa_create "$PROJECT_CORE" "caep-uk-core-runtime" "UK Core runtime SA"
_iam_sa_bind_role "$PROJECT_CORE" "caep-uk-core-runtime@${PROJECT_CORE}.iam.gserviceaccount.com" "roles/run.invoker"
_iam_sa_bind_role "$PROJECT_CORE" "caep-uk-core-runtime@${PROJECT_CORE}.iam.gserviceaccount.com" "roles/artifactregistry.reader"

# ---------- 4. Secret ----------
# ⚠ 真实 password 来自 1Password,不在本脚本硬编码。
#    本脚本只放占位,实际跑时手动:
#      1password read op://Prod/caep-uk-core-db/password > /tmp/secret.txt
#      _secret_put $PROJECT_CORE caep-uk-core-db-password /tmp/secret.txt
#      rm /tmp/secret.txt
_log_warn "Secret caep-uk-core-db-password 需要手工跑 _secret_put,本脚本不内置"

# ---------- 5. 收集资源快照到 artifacts/ (用 lib-artifact 统一) ----------
_log_info "收集资源快照到 ${ARTIFACT_DIR}/"
_artifact_capture "${ARTIFACT_DIR}/uk-bucket-artifacts.json" "UK artifacts bucket" \
    storage buckets describe "gs://caep-uk-core-artifacts" --project="$PROJECT_CORE"
_artifact_capture "${ARTIFACT_DIR}/uk-gar-images.json" "UK GAR images repo" \
    artifacts repositories describe "caep-uk-core-images" \
    --project="$PROJECT_CORE" --location="$DEFAULT_GAR_LOCATION"
_artifact_capture "${ARTIFACT_DIR}/uk-sa-runtime.json" "UK core runtime SA" \
    iam service-accounts describe "caep-uk-core-runtime@${PROJECT_CORE}.iam.gserviceaccount.com" \
    --project="$PROJECT_CORE"

_log_section "UK Setup 完成"
_log_info "✅ UK Region setup 跑完,artifacts 已落盘 (${ARTIFACT_DIR}/)"
