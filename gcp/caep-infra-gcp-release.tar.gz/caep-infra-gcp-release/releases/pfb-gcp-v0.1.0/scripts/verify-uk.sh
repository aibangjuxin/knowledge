#!/opt/homebrew/bin/bash
# scripts/verify-uk.sh — UK Region 验证
# 退出码 0 = 全部通过, 非 0 = 有失败项
#
# 改版 (Phase 2 enhancement): 用 lib-assert.sh 替代 10 次重复的
# if/then/_log_info ✅/❌/RESULTS 累计模式。
# =============================================================
set -uo pipefail  # 注意: 不开 -e,verify 要把每项都跑完

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/../../.." && pwd)"

source "${ROOT_DIR}/common/lib/lib-log.sh"
source "${ROOT_DIR}/common/lib/lib-bucket.sh"
source "${ROOT_DIR}/common/lib/lib-gar.sh"
source "${ROOT_DIR}/common/lib/lib-iam.sh"
source "${ROOT_DIR}/common/lib/lib-secret.sh"
source "${ROOT_DIR}/common/lib/lib-assert.sh"
source "${ROOT_DIR}/regions/uk/env.sh"

# lib-assert 要求 ARTIFACT_DIR 已定义
ARTIFACT_DIR="${SCRIPT_DIR}/../artifacts"
export ARTIFACT_DIR
mkdir -p "$ARTIFACT_DIR"

_log_section "UK Verify — pfb-gcp-v0.1.0"

# 资源存在类断言 (复用 _xxx_exists lib 函数)
_assert_resource_exists "bucket caep-uk-core-artifacts 存在" \
    _bucket_exists "$PROJECT_CORE" "caep-uk-core-artifacts"

_assert_resource_exists "GAR repo caep-uk-core-images 存在" \
    _gar_repo_exists "$PROJECT_CORE" "$DEFAULT_GAR_LOCATION" "caep-uk-core-images"

_assert_resource_exists "SA caep-uk-core-runtime 存在" \
    _iam_sa_exists "$PROJECT_CORE" "caep-uk-core-runtime@${PROJECT_CORE}.iam.gserviceaccount.com"

_assert_resource_exists "Secret caep-uk-core-db-password 存在" \
    _secret_exists "$PROJECT_CORE" "caep-uk-core-db-password"

# 打印 + 落盘 + 返回正确的退出码
_assert_summary "uk-verify"
exit $(_assert_exit_code && echo 0 || echo 1)
