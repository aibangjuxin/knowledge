#!/opt/homebrew/bin/bash
# =============================================================
# scripts/check-release.sh — release 跑前健康检查
# 检查 common/lib 完整性、_template/ 没被改、新版本 README 结构、
# commit 符合 Conventional Commits、tag 全部为 annotated
# =============================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

FAILED=0
_log_check() {
    if [[ "$1" == "OK" ]]; then
        echo "✅  $2"
    else
        echo "❌  $2"
        FAILED=1
    fi
}

# Conventional Commits 1.0.0 正则
CC_PATTERN='^(feat|fix|chore|docs|refactor|perf|test|build|ci|release|revert)(\([a-z0-9_-]+\))?!?: .+'

echo "==> 1. common/lib 完整性 + VERSION header"
for f in lib-log.sh lib-bucket.sh lib-gar.sh lib-secret.sh lib-dns.sh lib-iam.sh lib-gke.sh lib-jump.sh lib-gcp.sh lib-artifact.sh lib-assert.sh; do
    if [[ -f "${ROOT_DIR}/common/lib/${f}" ]]; then
        _log_check OK "common/lib/${f} 存在"
        # 检查 VERSION header
        if grep -qE "^LIB_[A-Z_]+_VERSION=\"[0-9]+\.[0-9]+\.[0-9]+\"" "${ROOT_DIR}/common/lib/${f}"; then
            _log_check OK "  └ VERSION header 合规"
        else
            _log_check FAIL "  └ 缺 LIB_XXX_VERSION=\"x.y.z\" header"
        fi
    else
        _log_check FAIL "common/lib/${f} 缺失"
    fi
done

echo ""
echo "==> 2. _template/ 是否被改(应该与 git HEAD 一致)"
if git -C "$ROOT_DIR" diff --quiet HEAD -- releases/_template/ 2>/dev/null; then
    _log_check OK "_template/ 未被本地修改"
else
    _log_check FAIL "_template/ 有本地修改!🚫 模板不准改,新需求放 releases/<v>/README.local.md"
    git -C "$ROOT_DIR" diff HEAD -- releases/_template/ | head -20
fi

echo ""
echo "==> 3. 所有 release README 是否含必需 section"
for readme in "${ROOT_DIR}"/releases/pfb-gcp-v*/README.md "${ROOT_DIR}"/releases/caep-infra-v*/README.md; do
    [[ -f "$readme" ]] || continue
    ver=$(basename "$(dirname "$readme")")
    for section in "## 0. 修订记录" "## 1. 基本元信息" "## 2. 变更范围" "## 5. 验证结果" "## 6. 已知缺口" "## 7. 踩坑实录" "## 8. CR 回填引用"; do
        if grep -qF "$section" "$readme"; then
            _log_check OK "$ver  含 $section"
        else
            _log_check FAIL "$ver  缺 $section"
        fi
    done
done

echo ""
echo "==> 4. 最近 20 个 commit 是否符合 Conventional Commits 1.0.0"
CC_BAD=0
CC_TOTAL=0
# bash 5: mapfile 一次读完 (替代 while-pipe)
mapfile -t CC_SUBJECTS < <(git -C "$ROOT_DIR" log -20 --pretty=%s)
for subject in "${CC_SUBJECTS[@]}"; do
    [[ -z "$subject" ]] && continue
    # 跳过 merge / revert 自动消息
    if [[ "$subject" =~ ^Merge\  ]] || [[ "$subject" =~ ^Revert\ \" ]]; then
        continue
    fi
    CC_TOTAL=$((CC_TOTAL+1))
    if ! [[ "$subject" =~ $CC_PATTERN ]]; then
        echo "  ❌  不规范: $subject"
        CC_BAD=$((CC_BAD+1))
    fi
done
if [[ $CC_BAD -eq 0 ]]; then
    _log_check OK "$CC_TOTAL 个 commit 全部符合 Conventional Commits"
else
    _log_check FAIL "$CC_BAD / $CC_TOTAL 个 commit 不规范 (例: 'release: open UK first Project rollout')"
fi

echo ""
echo "==> 5. 所有 release tag 是否为 annotated (不是 lightweight)"
TAG_OK=0
TAG_BAD=0
for t in $(git -C "$ROOT_DIR" tag --list 'pfb-gcp-v*' 'caep-infra-v*'); do
    # git cat-file -t <tag> 输出 "tag" (annotated) 或 "commit" (lightweight)
    obj_type=$(git -C "$ROOT_DIR" cat-file -t "$t" 2>/dev/null || echo "unknown")
    if [[ "$obj_type" == "tag" ]]; then
        TAG_OK=$((TAG_OK+1))
    else
        echo "  ❌  $t 是 $obj_type (应为 annotated, 用 'git tag -a $t -m \"...\"' 修复)"
        TAG_BAD=$((TAG_BAD+1))
    fi
done
if [[ $TAG_BAD -eq 0 ]]; then
    _log_check OK "$TAG_OK 个 release tag 全部是 annotated"
else
    _log_check FAIL "$TAG_BAD / $((TAG_OK+TAG_BAD)) 个 tag 不是 annotated"
fi

echo ""
echo "==> 6. commit-msg hook 是否启用(从 scripts/hooks/ 自动安装)"
HOOK_SRC="${ROOT_DIR}/scripts/hooks/commit-msg"
HOOK_DST="${ROOT_DIR}/.git/hooks/commit-msg"
if [[ ! -f "$HOOK_SRC" ]]; then
    _log_check FAIL "scripts/hooks/commit-msg 不存在 — hook 模板丢失"
elif [[ -x "$HOOK_DST" ]] && cmp -s "$HOOK_SRC" "$HOOK_DST"; then
    _log_check OK "commit-msg hook 已安装并与 scripts/hooks/commit-msg 一致"
else
    echo "  ⚠️   hook 未安装或与模板不一致,正在自动同步..."
    cp "$HOOK_SRC" "$HOOK_DST"
    chmod +x "$HOOK_DST"
    _log_check OK "已从 scripts/hooks/commit-msg 安装到 .git/hooks/commit-msg"
fi

echo ""
if [[ $FAILED -eq 0 ]]; then
    echo "✅ 全部检查通过"
    exit 0
else
    echo "❌ 有失败项,见上"
    exit 1
fi
