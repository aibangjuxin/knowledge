#!/opt/homebrew/bin/bash
# =============================================================
# scripts/cr-sync.sh — CR 状态同步 (GitHub 接入前的占位)
# =============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

usage() {
    cat <<EOF
用法: $0 <subcommand> [args]

subcommand:
  pull <release>       从 CR 系统拉取 cr/<id>.md 原始工单 (占位,等接入)
  push <release>       把 cr/<id>-filled.md 推到 CR 系统 (占位,等接入)
  status <release>     显示当前 release 的 CR 状态 (本地扫描)

例:
  $0 pull pfb-gcp-v0.1.0
  $0 status pfb-gcp-v0.1.0
EOF
}

case "${1:-}" in
    pull|push)
        echo "⚠ 暂未实现:等公司允许外网后接入 CR 系统 API(Jira / ServiceNow / 自研)"
        echo "   当前 workaround: 手工把 CR 系统的 markdown 复制到 releases/<release>/cr/<id>.md"
        exit 1
        ;;
    status)
        RELEASE="${2:-}"
        if [[ -z "$RELEASE" ]]; then
            echo "用法: $0 status <release>"; exit 1
        fi
        CR_DIR="${ROOT_DIR}/releases/${RELEASE}/cr"
        if [[ ! -d "$CR_DIR" ]]; then
            echo "❌ ${CR_DIR} 不存在"; exit 1
        fi
        echo "CR 状态 — ${RELEASE}"
        echo "===================="
        for f in "$CR_DIR"/*.md; do
            [[ -f "$f" ]] || continue
            name=$(basename "$f")
            echo "  - $name ($(wc -l < "$f") 行)"
        done
        ;;
    *)
        usage
        exit 1
        ;;
esac
