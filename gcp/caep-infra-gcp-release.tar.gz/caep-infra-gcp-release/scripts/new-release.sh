#!/opt/homebrew/bin/bash
# =============================================================
# scripts/new-release.sh — 创建新 release 脚手架
# 用法: ./scripts/new-release.sh <version>
# 例:   ./scripts/new-release.sh pfb-gcp-v0.1.0
# 支持的 version prefix: caep-infra-vX.Y.Z | pfb-gcp-vX.Y.Z
# =============================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"

VERSION="${1:-}"
if [[ -z "$VERSION" ]]; then
    echo "用法: $0 <version>"
    echo "例:   $0 pfb-gcp-v0.1.0"
    exit 1
fi

# 校验版本号格式: <prefix>vX.Y.Z,prefix 可选 (字母数字短横线),后缀 -xxx 也可选
if ! [[ "$VERSION" =~ ^([a-z0-9-]+-)?v[0-9]+\.[0-9]+\.[0-9]+(-[a-z0-9.]+)?$ ]]; then
    echo "❌ 版本号格式错: ${VERSION}"
    echo "   必须匹配: <prefix>vX.Y.Z  (例 pfb-gcp-v0.1.0, caep-infra-v1.2.3, pfb-gcp-v1.2.3-rollback)"
    echo "   prefix 部分可选 (字母数字短横线),核心是 vX.Y.Z"
    exit 1
fi

TARGET="${ROOT_DIR}/releases/${VERSION}"
if [[ -d "$TARGET" ]]; then
    echo "❌ ${TARGET} 已存在,拒绝覆盖。请手工处理。"
    exit 1
fi

echo "==> 创建 ${TARGET}/ (基于 _template/)"
cp -R "${ROOT_DIR}/releases/_template" "$TARGET"

echo "==> 给子目录加 .gitkeep (确保空目录也能入仓)"
touch "$TARGET/scripts/.gitkeep"
touch "$TARGET/artifacts/.gitkeep"
touch "$TARGET/cr/.gitkeep"
touch "$TARGET/report/.gitkeep"

echo ""
echo "✅ 新 release 脚手架已建好: ${TARGET}"
echo ""

# 自动创建 release branch (如不存在)
BRANCH="release/${VERSION}"
if git -C "$ROOT_DIR" rev-parse --verify "$BRANCH" >/dev/null 2>&1; then
    echo "ℹ️  分支 ${BRANCH} 已存在,直接切到该分支"
    git -C "$ROOT_DIR" checkout "$BRANCH"
else
    echo "==> 创建分支 ${BRANCH}"
    git -C "$ROOT_DIR" checkout -b "$BRANCH"
fi

echo ""
echo "下一步:"
echo "  1) 编辑 \${TARGET}/README.md 第 1 节 \"基本元信息\""
echo "  2) cp common/lib/lib-*.sh \${TARGET}/scripts/  按需 source"
echo "  3) 跑 ./\${TARGET}/scripts/preflight-<region>.sh"
echo "  4) 跑 setup + verify"
echo "  5) git add + commit (commit-msg hook 强制 Conventional Commits)"
echo "  6) git tag -a \${VERSION} -m \"Release \${VERSION} — <one-line summary>\" (annotated tag)"
echo "  7) merge \${BRANCH} 到 main 后 git push"
